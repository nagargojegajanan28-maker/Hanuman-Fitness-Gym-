package com.hanuman.fitness

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.TextStyle
import java.util.Locale

fun msToDate(ms: Long): String = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate().toString()
fun hasPerm(ctx: Context, p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
fun stepPermGranted(ctx: Context) = Build.VERSION.SDK_INT < 29 || hasPerm(ctx, Manifest.permission.ACTIVITY_RECOGNITION)

@Composable
fun ProgressTab(vm: AppVM) {
    val d = vm.data
    var tab by remember { mutableIntStateOf(0) }
    var range by remember { mutableStateOf("Week") }
    var addWeight by remember { mutableStateOf(false) }
    val n = if (range == "Week") 7 else 30
    val dates = (n - 1 downTo 0).map { daysAgo(it) }
    val labels = dates.map { if (n == 7) LocalDate.parse(it).dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()) else it.substring(8) }
    val u = d.settings.units
    val wLogs = d.workoutLogs.filter { msToDate(it.startedAt) in dates }
    val wMin = dates.map { dt -> d.workoutLogs.filter { msToDate(it.startedAt) == dt }.sumOf { it.durationSec } / 60f }
    val eatenKcal = dates.map { dt -> d.meals.filter { it.date == dt && it.eaten }.sumOf { (Library.meal(it.mealId)?.kcal ?: 0) * it.servings }.toFloat() }
    val weights = d.weights.filter { it.date in dates }
    Column(Modifier.fillMaxSize()) {
        Header("Progress")
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SegTabs(listOf("Overview", "Weight", "Workouts", "Nutrition"), tab) { tab = it }
            ChipRow(listOf("Week", "Month"), range) { range = it }
            when (tab) {
                0 -> {
                    val steps = dates.sumOf { d.steps[it] ?: 0 }
                    val runs = d.runLogs.filter { msToDate(it.startedAt) in dates }
                    val hasData = wLogs.isNotEmpty() || steps > 0 || runs.isNotEmpty() || d.weights.isNotEmpty()
                    if (!hasData) Empty("No data yet", "Finish a workout, log your weight or enable step counting and your progress will show up here.", Icons.Default.Insights)
                    else {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Stat("Workouts", "${wLogs.size}", Modifier.weight(1f)); Stat("Active min", "${wLogs.sumOf { it.durationSec } / 60}", Modifier.weight(1f))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Stat("Steps", "$steps", Modifier.weight(1f)); Stat("Avg steps/day", "${steps / n}", Modifier.weight(1f))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Stat("Run/walk dist.", fmtDist(runs.sumOf { it.distanceM }, u), Modifier.weight(1f))
                            Stat("Current weight", d.weights.lastOrNull()?.let { fmtW(it.kg, u) } ?: "--", Modifier.weight(1f))
                        }
                        if (d.habits.isNotEmpty()) {
                            val possible = d.habits.size * n
                            val doneC = dates.sumOf { dt -> d.habits.count { it.id in (d.habitDone[dt] ?: emptyList()) } }
                            Stat("Habit completion", "${doneC * 100 / possible}%", Modifier.fillMaxWidth())
                        }
                    }
                }
                1 -> {
                    GradBtn("Log today's weight", { addWeight = true }, icon = Icons.Default.Add)
                    if (weights.isEmpty()) Empty("No weight entries in this period", "Log your weight to see your trend.", Icons.Default.MonitorWeight)
                    else HCard {
                        val vals = weights.map { (if (u == "imperial") kgToLb(it.kg) else it.kg).toFloat() }
                        Text("Weight (${if (u == "imperial") "lb" else "kg"})", fontWeight = FontWeight.Bold)
                        if (weights.size >= 2) Text("Change: ${fmt1(vals.last() - vals.first().toDouble())}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(8.dp)); LineChart(vals, weights.map { it.date.substring(5) })
                    }
                    d.weights.takeLast(10).reversed().forEach { HCard { Row { Text(it.date, Modifier.weight(1f)); Text(fmtW(it.kg, u), fontWeight = FontWeight.SemiBold) } } }
                }
                2 -> {
                    if (wLogs.isEmpty()) Empty("No workouts in this period", "Finished workouts appear here.", Icons.Default.FitnessCenter)
                    else HCard { Text("Active minutes per day", fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); BarChart(wMin, labels) }
                    d.workoutLogs.takeLast(10).reversed().forEach { HCard { Text(it.name, fontWeight = FontWeight.SemiBold); Text("${msToDate(it.startedAt)} • ${fmtTime(it.durationSec.toLong())} • ${it.done}/${it.total} exercises", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
                }
                else -> {
                    if (eatenKcal.all { it == 0f }) Empty("No nutrition history", "Mark meals as eaten in the Nutrition tab to build your history.", Icons.Default.Restaurant)
                    else HCard {
                        Text("Calories eaten per day (est.)", fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); BarChart(eatenKcal, labels, Brand.Green)
                        val days = eatenKcal.count { it > 0 }
                        Text("Average on logged days: ${(eatenKcal.sum() / days).toInt()} kcal", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
    if (addWeight) {
        var t by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { addWeight = false }, title = { Text("Log weight") },
            text = { Field(if (u == "imperial") "Weight (lb)" else "Weight (kg)", t, { t = it.filter { c -> c.isDigit() || c == '.' }.take(6) }, decimal = true) },
            confirmButton = { TextButton(onClick = {
                val v = t.toDoubleOrNull()
                val kg = if (v == null) null else if (u == "imperial") lbToKg(v) else v
                if (kg != null && kg in 20.0..350.0) { vm.addWeight(kg); addWeight = false } else vm.notice = "Enter a realistic weight."
            }) { Text("Save", color = Brand.Purple) } },
            dismissButton = { TextButton(onClick = { addWeight = false }) { Text("Cancel") } })
    }
}

@Composable
private fun Stat(label: String, value: String, modifier: Modifier) {
    HCard(modifier) { Text(value, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold); Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
}

@Composable
fun ActivityScreen(vm: AppVM) {
    val ctx = LocalContext.current
    val d = vm.data
    val u = d.settings.units
    var stepPerm by remember { mutableStateOf(stepPermGranted(ctx)) }
    var locPerm by remember { mutableStateOf(hasPerm(ctx, Manifest.permission.ACCESS_FINE_LOCATION)) }
    var gpsOn by remember { mutableStateOf(false) }
    var type by remember { mutableStateOf("Run") }
    var finish by remember { mutableStateOf(false) }
    var goalDialog by remember { mutableStateOf(false) }
    var strideDialog by remember { mutableStateOf(false) }
    var tickNow by remember { mutableLongStateOf(0L) }
    val stepLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> stepPerm = ok; if (ok) vm.startSteps() }
    val locLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        locPerm = res[Manifest.permission.ACCESS_FINE_LOCATION] == true
        gpsOn = locPerm
        if (!locPerm) vm.notice = "Location permission denied. You can still use timer-only mode."
    }
    val run = vm.run
    val view = LocalView.current
    DisposableEffect(run != null) { view.keepScreenOn = run != null && d.settings.keepScreenOn; onDispose { view.keepScreenOn = false } }
    LaunchedEffect(run) { while (run != null) { run.tick(); tickNow++; delay(250) } }
    if (tickNow < 0) return

    Column(Modifier.fillMaxSize()) {
        Header("Activity", onBack = { vm.pop() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            HCard {
                Text("Steps", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                if (!vm.stepSupported) {
                    Text("This device does not have a hardware step counter, so automatic step counting isn't available. You can still record runs and walks below.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else if (!stepPerm) {
                    Text("Step counting uses your phone's motion sensor and needs the Physical activity permission. Nothing is sent anywhere.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    GradBtn("Enable step counting", { stepLauncher.launch(Manifest.permission.ACTIVITY_RECOGNITION) })
                } else {
                    val steps = vm.stepsToday()
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Ring(if (d.profile.stepGoal > 0) steps / d.profile.stepGoal.toFloat() else 0f, 120, 12) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("$steps", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold); Text("of ${d.profile.stepGoal}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        }
                        Column {
                            val s = vm.strideM()
                            if (s > 0) Text("≈ ${fmtDist(steps * s, u)} (estimate)", fontWeight = FontWeight.Medium) else Text("Set your height or stride length to estimate distance.", fontSize = 13.sp)
                            if (s > 0) Text("Using a stride of ${String.format(Locale.US, "%.2f", s)} m", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Row { TextButton(onClick = { goalDialog = true }) { Text("Step goal", color = Brand.Purple) }; TextButton(onClick = { strideDialog = true }) { Text("Stride length", color = Brand.Purple) } }
                    Text("Steps are counted by the phone's sensor. Steps taken while the app was closed are added the next time you open it. Counts may not be exact.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            HCard {
                Text("Run / Walk session", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                if (run == null) {
                    Spacer(Modifier.height(8.dp))
                    ChipRow(listOf("Run", "Walk"), type) { type = it }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("Track distance with GPS", fontWeight = FontWeight.Medium); Text("Needs location permission, uses more battery. Off = timer only.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        Switch(gpsOn, { on -> if (on && !locPerm) locLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) else gpsOn = on })
                    }
                    GradBtn("Start $type", {
                        var useGps = gpsOn && locPerm
                        if (useGps && !(ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager).isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                            vm.notice = "GPS is turned off on your phone, so this session will be timer only."; useGps = false
                        }
                        vm.startRun(type, useGps)
                    }, icon = Icons.Default.PlayArrow)
                } else {
                    val sec = run.accMs / 1000
                    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(fmtTime(sec), fontSize = 52.sp, fontWeight = FontWeight.ExtraBold)
                        if (run.gps) {
                            Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(fmtDist(run.distanceM, u), fontWeight = FontWeight.Bold, fontSize = 20.sp); Text("Distance", fontSize = 12.sp) }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(fmtPace(run.distanceM, sec, u), fontWeight = FontWeight.Bold, fontSize = 20.sp); Text("Pace", fontSize = 12.sp) }
                            }
                            Text(run.gpsAccuracy?.let { "GPS accuracy ±${it.toInt()} m" } ?: "Waiting for GPS signal…", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        } else Text("Timer only — distance and pace are not tracked.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                        if (!run.running) Text("Paused", color = Brand.Orange, fontWeight = FontWeight.Bold)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(Modifier.weight(1f)) { GradBtn(if (run.running) "Pause" else "Resume", { if (run.running) run.pause() else run.resume() }, icon = if (run.running) Icons.Default.Pause else Icons.Default.PlayArrow) }
                        Box(Modifier.weight(1f)) { OutBtn("Finish", { run.pause(); finish = true }) }
                    }
                    Text("Keep the screen on while tracking. GPS tracking pauses if the app is sent to the background. Distance is approximate.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Section("History")
            if (d.runLogs.isEmpty()) Text("No sessions saved yet.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            d.runLogs.takeLast(15).reversed().forEach { r ->
                HCard {
                    Text("${r.type} • ${msToDate(r.startedAt)}", fontWeight = FontWeight.SemiBold)
                    Text(if (r.gps) "${fmtTime(r.durationSec.toLong())} • ${fmtDist(r.distanceM, u)} • ${fmtPace(r.distanceM, r.durationSec.toLong(), u)}" else "${fmtTime(r.durationSec.toLong())} • timer only", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
    if (finish && run != null) AlertDialog(onDismissRequest = { finish = false }, title = { Text("Finish session?") },
        text = { Text("Time ${fmtTime(run.accMs / 1000)}${if (run.gps) " • ${fmtDist(run.distanceM, u)}" else ""}. Save it to your history?") },
        confirmButton = { TextButton(onClick = { vm.saveRun(run); finish = false }) { Text("Save", color = Brand.Purple) } },
        dismissButton = { Row { TextButton(onClick = { finish = false }) { Text("Keep going") }; TextButton(onClick = { vm.discardRun(); finish = false }) { Text("Discard", color = Brand.Red) } } })
    if (goalDialog) {
        var t by remember { mutableStateOf(d.profile.stepGoal.toString()) }
        AlertDialog(onDismissRequest = { goalDialog = false }, title = { Text("Daily step goal") },
            text = { Field("Steps", t, { t = it.filter(Char::isDigit).take(6) }, number = true) },
            confirmButton = { TextButton(onClick = { val v = t.toIntOrNull() ?: 0; if (v in 500..100000) { vm.update { it.copy(profile = it.profile.copy(stepGoal = v)) }; goalDialog = false } }) { Text("Save", color = Brand.Purple) } },
            dismissButton = { TextButton(onClick = { goalDialog = false }) { Text("Cancel") } })
    }
    if (strideDialog) {
        var t by remember { mutableStateOf(if (d.settings.strideCm > 0) d.settings.strideCm.toString() else "") }
        AlertDialog(onDismissRequest = { strideDialog = false }, title = { Text("Stride length (cm)") },
            text = { Column { Text("Leave blank to estimate from your height (height × 0.415).", fontSize = 13.sp); Field("Stride (cm)", t, { t = it.filter(Char::isDigit).take(3) }, number = true) } },
            confirmButton = { TextButton(onClick = { val v = t.toIntOrNull() ?: 0; if (v == 0 || v in 30..150) { vm.update { it.copy(settings = it.settings.copy(strideCm = v)) }; strideDialog = false } }) { Text("Save", color = Brand.Purple) } },
            dismissButton = { TextButton(onClick = { strideDialog = false }) { Text("Cancel") } })
    }
}
