package com.hanuman.fitness

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

fun num(d: Double): String = if (d % 1.0 == 0.0) d.toInt().toString() else fmt1(d)

@Composable
fun NutritionTab(vm: AppVM) {
    val d = vm.data
    var date by remember { mutableStateOf(today()) }
    var addSlot by remember { mutableStateOf<String?>(null) }
    var editTarget by remember { mutableStateOf(false) }
    val days = (-3..3).map { LocalDate.now().plusDays(it.toLong()) }
    val items = d.meals.filter { it.date == date }
    fun sum(list: List<PlanMeal>, f: (Meal) -> Int) = list.sumOf { (Library.meal(it.mealId)?.let(f) ?: 0) * it.servings }
    val planned = sum(items) { it.kcal }.toInt()
    val eaten = items.filter { it.eaten }
    val target = if (d.settings.calorieTarget > 0) d.settings.calorieTarget else Library.estimateCalories(d.profile)
    Column(Modifier.fillMaxSize()) {
        Header("Nutrition")
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                days.forEach { day ->
                    val sel = day.toString() == date
                    Column(
                        Modifier.clip(RoundedCornerShape(14.dp)).background(if (sel) Brand.Purple else MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { date = day.toString() }.padding(horizontal = 14.dp, vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(day.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()), fontSize = 11.sp, color = if (sel) Color.White else MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${day.dayOfMonth}", fontWeight = FontWeight.Bold, color = if (sel) Color.White else MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
            HCard {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Ring(if (target != null && target > 0) planned / target.toFloat() else 0f, 110, 11, Brand.Purple) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("$planned", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold); Text("kcal planned", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) { Dot(Brand.Purple); Text("Protein ${sum(items) { it.protein }.toInt()} g", fontSize = 13.sp) }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) { Dot(Brand.Blue); Text("Carbs ${sum(items) { it.carbs }.toInt()} g", fontSize = 13.sp) }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) { Dot(Brand.Green); Text("Fat ${sum(items) { it.fat }.toInt()} g", fontSize = 13.sp) }
                        Text("Eaten: ${sum(eaten) { it.kcal }.toInt()} kcal", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(if (target != null) "Daily target: $target kcal (${if (d.settings.calorieTarget > 0) "set by you" else "estimated from your profile"})" else "Add age, height and weight in Profile, or set a target, to see a calorie goal.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton(onClick = { editTarget = true }) { Text("Set calorie target", color = Brand.Purple) }
                Text("Calories and macros are estimates based on typical recipes.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Library.slots.forEach { slot ->
                val sl = items.filter { it.slot == slot }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(slot, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
                    TextButton(onClick = { addSlot = slot }) { Icon(Icons.Default.Add, null, Modifier.size(18.dp)); Text("Add", color = Brand.Purple) }
                }
                if (sl.isEmpty()) Text("Nothing planned", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                sl.forEach { pm ->
                    val m = Library.meal(pm.mealId) ?: return@forEach
                    HCard(onClick = { vm.push(Route.MealDetail(m.id, date, slot)) }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(pm.eaten, { vm.toggleEaten(pm.id) })
                            Column(Modifier.weight(1f)) {
                                Text(m.name, fontWeight = FontWeight.SemiBold)
                                Text("${(m.kcal * pm.servings).toInt()} kcal • ${num(pm.servings)} serving(s)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton(onClick = { vm.setServings(pm.id, maxOf(0.5, pm.servings - 0.5)) }) { Icon(Icons.Default.Remove, "Fewer servings") }
                            IconButton(onClick = { vm.setServings(pm.id, pm.servings + 0.5) }) { Icon(Icons.Default.Add, "More servings") }
                            IconButton(onClick = { vm.removeMeal(pm.id) }) { Icon(Icons.Default.Delete, "Remove meal", tint = Brand.Red) }
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
    addSlot?.let { slot ->
        val all = Library.meals.filter { it.slot == slot }
        val ok = all.filter { Library.mealAllowed(it, d.profile.diet, d.profile.allergies) }
        AlertDialog(onDismissRequest = { addSlot = null }, title = { Text("Add to $slot") },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) {
                if (ok.size < all.size) Text("${all.size - ok.size} meal(s) hidden by your diet/allergy settings.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (ok.isEmpty()) Text("No meals match your preferences.")
                ok.forEach { m -> Row(Modifier.fillMaxWidth().clickable { addSlot = null; vm.push(Route.MealDetail(m.id, date, slot)) }.padding(vertical = 10.dp)) {
                    Column(Modifier.weight(1f)) { Text(m.name, fontWeight = FontWeight.Medium); Text("${m.kcal} kcal (est.) • P${m.protein} C${m.carbs} F${m.fat}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) } } }
            } },
            confirmButton = { TextButton(onClick = { addSlot = null }) { Text("Close") } })
    }
    if (editTarget) {
        var t by remember { mutableStateOf(if (d.settings.calorieTarget > 0) d.settings.calorieTarget.toString() else "") }
        AlertDialog(onDismissRequest = { editTarget = false }, title = { Text("Daily calorie target") },
            text = { Column { Field("kcal per day (blank = estimate)", t, { t = it.filter(Char::isDigit).take(5) }, number = true) } },
            confirmButton = { TextButton(onClick = { val v = t.toIntOrNull() ?: 0; if (v == 0 || v in 800..6000) { vm.update { it.copy(settings = it.settings.copy(calorieTarget = v)) }; editTarget = false } }) { Text("Save", color = Brand.Purple) } },
            dismissButton = { TextButton(onClick = { editTarget = false }) { Text("Cancel") } })
    }
}

@Composable
fun MealDetailScreen(vm: AppVM, r: Route.MealDetail) {
    val m = Library.meal(r.mealId)
    var servings by remember { mutableDoubleStateOf(1.0) }
    var slot by remember { mutableStateOf(r.slot) }
    Column(Modifier.fillMaxSize()) {
        Header("Meal Details", onBack = { vm.pop() })
        if (m == null) { Empty("Meal not found", ""); return@Column }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.fillMaxWidth().height(110.dp).clip(RoundedCornerShape(20.dp)).background(Brand.Gradient), contentAlignment = Alignment.Center) { Icon(Icons.Default.Restaurant, null, tint = Color.White, modifier = Modifier.size(52.dp)) }
            Text(m.name, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            Text("${(m.kcal * servings).toInt()} kcal (estimate)", color = Brand.Purple, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("Protein" to m.protein, "Carbs" to m.carbs, "Fat" to m.fat).forEach { (n, v) ->
                    HCard(Modifier.weight(1f)) { Text("${(v * servings).toInt()} g", fontWeight = FontWeight.Bold, fontSize = 18.sp); Text(n, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Servings", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                FilledTonalIconButton(onClick = { servings = maxOf(0.5, servings - 0.5) }) { Icon(Icons.Default.Remove, "Fewer") }
                Text(num(servings), fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(horizontal = 16.dp))
                FilledTonalIconButton(onClick = { servings += 0.5 }) { Icon(Icons.Default.Add, "More") }
            }
            Section("Ingredients")
            m.ings.forEach { Text("• ${num(it.qty * servings)}${if (it.unit.isNotBlank()) " ${it.unit}" else ""} ${it.name}") }
            Section("Preparation")
            Text(m.note)
            if (m.allergens.isNotEmpty()) Text("Contains: ${m.allergens.joinToString(", ")}", fontSize = 13.sp, color = Brand.Orange)
            Text("Add to", fontWeight = FontWeight.SemiBold); ChipRow(Library.slots, slot) { slot = it }
            Text("Nutrition values are estimates for typical recipes and portions.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            GradBtn("Add to Meal Plan", { vm.addMeal(m.id, r.date, slot, servings); vm.notice = "Added to your meal plan."; vm.pop() })
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
fun HabitsScreen(vm: AppVM) {
    val d = vm.data
    var date by remember { mutableStateOf(today()) }
    var dialog by remember { mutableStateOf<Habit?>(null) }
    var adding by remember { mutableStateOf(false) }
    var delete by remember { mutableStateOf<Habit?>(null) }
    val done = d.habitDone[date] ?: emptyList()
    Column(Modifier.fillMaxSize()) {
        Header("Daily Habits", onBack = { vm.pop() }, actions = { IconButton(onClick = { adding = true }) { Icon(Icons.Default.Add, "Add habit") } })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                (6 downTo 0).map { LocalDate.now().minusDays(it.toLong()) }.forEach { day ->
                    val sel = day.toString() == date
                    val c = d.habits.count { it.id in (d.habitDone[day.toString()] ?: emptyList()) }
                    Column(Modifier.clip(RoundedCornerShape(12.dp)).background(if (sel) Brand.Purple else Color.Transparent).clickable { date = day.toString() }.padding(horizontal = 8.dp, vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(day.dayOfWeek.getDisplayName(TextStyle.NARROW, Locale.getDefault()), fontSize = 11.sp, color = if (sel) Color.White else MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${day.dayOfMonth}", fontWeight = FontWeight.Bold, color = if (sel) Color.White else MaterialTheme.colorScheme.onSurface)
                        Text("$c/${d.habits.size}", fontSize = 9.sp, color = if (sel) Color.White else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            Text(if (date == today()) "Today" else date, fontWeight = FontWeight.SemiBold)
            if (d.habits.isEmpty()) Empty("No habits yet", "Add habits you want to track, like water, sleep, walking or meditation.", Icons.Default.Favorite, "Add habit") { adding = true }
            d.habits.forEach { h ->
                val isDone = h.id in done
                HCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(32.dp).clip(CircleShape).background(if (isDone) Brand.Green else MaterialTheme.colorScheme.surfaceVariant).clickable { vm.toggleHabit(h.id, date) }, contentAlignment = Alignment.Center) {
                            if (isDone) Icon(Icons.Default.Check, "Completed", tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) { Text(h.name, fontWeight = FontWeight.SemiBold); if (h.target.isNotBlank()) Text("Target: ${h.target}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        IconButton(onClick = { dialog = h }) { Icon(Icons.Default.Edit, "Edit habit") }
                        IconButton(onClick = { delete = h }) { Icon(Icons.Default.Delete, "Delete habit", tint = Brand.Red) }
                    }
                }
            }
            if (d.habits.isNotEmpty()) Text("${d.habits.count { it.id in done }} of ${d.habits.size} completed. Habits only change when you tap them.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    if (adding || dialog != null) {
        val h = dialog
        var n by remember(h, adding) { mutableStateOf(h?.name ?: "") }
        var t by remember(h, adding) { mutableStateOf(h?.target ?: "") }
        AlertDialog(onDismissRequest = { adding = false; dialog = null }, title = { Text(if (h == null) "New habit" else "Edit habit") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { Field("Habit name", n, { n = it.take(40) }); Field("Target (optional, e.g. 2 L)", t, { t = it.take(20) }) } },
            confirmButton = { TextButton(enabled = n.isNotBlank(), onClick = { if (h == null) vm.addHabit(n, t) else vm.editHabit(h.id, n, t); adding = false; dialog = null }) { Text("Save", color = Brand.Purple) } },
            dismissButton = { TextButton(onClick = { adding = false; dialog = null }) { Text("Cancel") } })
    }
    delete?.let { h -> ConfirmDialog("Delete habit?", "\"${h.name}\" will be removed from your list.", "Delete", { vm.deleteHabit(h.id); delete = null }, { delete = null }, true) }
}
