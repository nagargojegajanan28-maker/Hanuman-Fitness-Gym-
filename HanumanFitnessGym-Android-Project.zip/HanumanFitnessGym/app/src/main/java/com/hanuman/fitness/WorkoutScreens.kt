package com.hanuman.fitness

import android.content.Context
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

fun muscleIcon(m: String) = when (m) {
    "Chest", "Arms", "Shoulders", "Back" -> Icons.Default.FitnessCenter
    "Legs" -> Icons.Default.Hiking; "Core" -> Icons.Default.SelfImprovement
    "Cardio" -> Icons.Default.Bolt; else -> Icons.Default.Spa
}
fun amtText(ex: Exercise, i: PlanEx) = if (ex.timed) "${i.sets} × ${i.amt}s" else "${i.sets} × ${i.amt} reps"

@Composable
fun WorkoutTab(vm: AppVM) {
    var tab by remember { mutableIntStateOf(0) }
    var cat by remember { mutableStateOf("All") }
    var q by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var detail by remember { mutableStateOf<Exercise?>(null) }
    Column(Modifier.fillMaxSize()) {
        Header("Workout", actions = { IconButton(onClick = { searching = !searching; if (!searching) q = "" }) { Icon(Icons.Default.Search, "Search") } })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SegTabs(listOf("Plans", "Exercises", "My Workouts"), tab) { tab = it }
            if (searching) Field("Search", q, { q = it })
            when (tab) {
                0 -> {
                    ChipRow(Library.categories, cat) { cat = it }
                    val list = Library.plans.filter { (cat == "All" || cat in it.category.split(",")) && it.name.contains(q, true) }
                    if (list.isEmpty()) Empty("No workouts found", "Try another category or search.")
                    list.forEach { PlanCard(it) { vm.push(Route.PlanDetail(it.id)) } }
                }
                1 -> {
                    var mus by remember { mutableStateOf("Any") }
                    ChipRow(Library.muscles.filter { it != "Full Body" }, mus) { mus = it }
                    Library.exercises.filter { (mus == "Any" || it.muscle == mus) && it.name.contains(q, true) }.forEach { ex ->
                        HCard(onClick = { detail = ex }) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                IconBox(muscleIcon(ex.muscle), Brand.Purple, Brand.Purple.copy(alpha = 0.12f), 44)
                                Column(Modifier.weight(1f)) { Text(ex.name, fontWeight = FontWeight.SemiBold); Text("${ex.muscle} • ${ex.equip}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                            }
                        }
                    }
                }
                else -> {
                    GradBtn("Create workout", { vm.push(Route.CreateWorkout) }, icon = Icons.Default.Add)
                    val mine = vm.data.customPlans.filter { it.name.contains(q, true) }
                    if (mine.isEmpty()) Empty("No saved workouts yet", "Create your own or save a generated workout from the builder.", Icons.Default.FitnessCenter)
                    mine.forEach { PlanCard(it) { vm.push(Route.PlanDetail(it.id)) } }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
    detail?.let { ex ->
        AlertDialog(onDismissRequest = { detail = null }, title = { Text(ex.name) },
            text = { Column { Text("${ex.muscle} • ${ex.equip}", color = Brand.Purple, fontSize = 13.sp); Spacer(Modifier.height(8.dp)); Text(ex.desc); Spacer(Modifier.height(8.dp)); Text("Suggested: " + amtText(ex, PlanEx(ex.id, ex.sets, ex.amt)), fontWeight = FontWeight.Medium) } },
            confirmButton = { TextButton(onClick = { detail = null }) { Text("Close") } })
    }
}

@Composable
fun PlanCard(p: Plan, onClick: () -> Unit) {
    HCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            IconBox(Icons.Default.FitnessCenter, Color.White, Brand.Purple, 52)
            Column(Modifier.weight(1f)) {
                Text(p.name, fontWeight = FontWeight.Bold)
                Text("${p.estMinutes()} min • ${p.items.size} exercises • ${p.level}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(p.category.replace(",", " · "), fontSize = 11.sp, color = Brand.Purple)
            }
            Icon(Icons.AutoMirrored.Filled.ArrowForward, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun PlanDetailScreen(vm: AppVM, id: String) {
    val p = vm.findPlan(id)
    var confirmDelete by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Header(p?.name ?: "Workout", onBack = { vm.pop() })
        if (p == null) { Empty("Workout not found", "It may have been deleted."); return@Column }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("${p.estMinutes()} min (est.)", true) {}; Chip("${p.items.size} exercises", false) {}; Chip(p.level, false) {}
            }
            if (p.blurb.isNotBlank()) Text(p.blurb, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Section("Exercises")
            p.items.forEachIndexed { i, it ->
                val ex = Library.ex(it.exId) ?: return@forEachIndexed
                HCard {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        IconBox(muscleIcon(ex.muscle), Brand.Purple, Brand.Purple.copy(alpha = 0.12f), 44)
                        Column(Modifier.weight(1f)) { Text("${i + 1}. ${ex.name}", fontWeight = FontWeight.SemiBold); Text(ex.muscle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        Text(amtText(ex, it), fontWeight = FontWeight.Medium, fontSize = 13.sp)
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            GradBtn("Start Workout", { vm.startWorkout(p) }, icon = Icons.Default.PlayArrow)
            OutBtn("Set as today's workout", { vm.setTodayPlan(p.id); vm.notice = "Added to Today's Plan." }, enabled = !p.generated)
            if (p.generated) OutBtn("Save to My Workouts", { vm.saveCustomPlan(p); vm.notice = "Saved to My Workouts." })
            if (vm.data.customPlans.any { it.id == p.id }) OutBtn("Delete workout", { confirmDelete = true }, danger = true)
            Spacer(Modifier.height(16.dp))
        }
    }
    if (confirmDelete) ConfirmDialog("Delete workout?", "This removes it from My Workouts.", "Delete", { vm.deleteCustomPlan(id); confirmDelete = false; vm.pop() }, { confirmDelete = false }, true)
}

@Composable
fun BuilderScreen(vm: AppVM) {
    val pr = vm.data.profile
    var goal by remember { mutableStateOf(pr.goal.ifBlank { "Stay Healthy" }) }
    var minutes by remember { mutableIntStateOf(30) }
    var level by remember { mutableStateOf(pr.level.ifBlank { "Beginner" }) }
    var muscle by remember { mutableStateOf("Any") }
    var equip by remember { mutableStateOf(pr.equipment.ifEmpty { listOf("Bodyweight") }.toSet()) }
    Column(Modifier.fillMaxSize()) {
        Header("Workout Builder", onBack = { vm.pop() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            HCard { Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Default.Info, null, tint = Brand.Purple)
                Text("This is a rule-based generator that picks exercises from the built-in library. It is not AI-generated.", fontSize = 13.sp)
            } }
            Text("Goal", fontWeight = FontWeight.SemiBold); ChipRow(Library.goals, goal) { goal = it }
            Text("Duration", fontWeight = FontWeight.SemiBold)
            ChipRow(listOf("15", "20", "30", "45", "60").map { "$it min" }, "$minutes min") { minutes = it.substringBefore(" ").toInt() }
            Text("Difficulty", fontWeight = FontWeight.SemiBold); ChipRow(Library.levels, level) { level = it }
            Text("Target muscle group", fontWeight = FontWeight.SemiBold); ChipRow(Library.muscles, muscle) { muscle = it }
            Text("Equipment", fontWeight = FontWeight.SemiBold)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Library.equipmentOptions.forEach { o ->
                    Chip(o, o in equip) { equip = if (o in equip && equip.size > 1) equip - o else equip + o }
                }
            }
            Text("Quick ideas", fontWeight = FontWeight.SemiBold)
            ChipRow(listOf("20 min with dumbbells", "Quick cardio at home", "Upper body strength", "Core and abs focus", "Full body HIIT"), "") { idea ->
                when (idea) {
                    "20 min with dumbbells" -> { minutes = 20; equip = setOf("Dumbbells", "Bodyweight"); muscle = "Any"; goal = "Build Muscle" }
                    "Quick cardio at home" -> { minutes = 20; equip = setOf("Bodyweight"); muscle = "Cardio"; goal = "Improve Endurance" }
                    "Upper body strength" -> { minutes = 30; muscle = "Chest"; goal = "Build Muscle" }
                    "Core and abs focus" -> { minutes = 15; muscle = "Core"; goal = "Stay Healthy" }
                    else -> { minutes = 30; muscle = "Cardio"; goal = "Lose Weight"; equip = setOf("Bodyweight") }
                }
            }
            Spacer(Modifier.height(4.dp))
            GradBtn("Generate Workout", {
                val plan = Library.generate(goal, minutes, level, muscle, equip)
                if (plan.items.isEmpty()) vm.notice = "No exercises match those choices. Add equipment or pick a different muscle group."
                else { vm.generated = plan; vm.push(Route.PlanDetail(plan.id)) }
            }, icon = Icons.Default.AutoAwesome)
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
fun CreateWorkoutScreen(vm: AppVM) {
    var name by remember { mutableStateOf("") }
    var picked by remember { mutableStateOf(listOf<String>()) }
    Column(Modifier.fillMaxSize()) {
        Header("Create Workout", onBack = { vm.pop() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Field("Workout name", name, { name = it.take(40) })
            Text("Pick exercises (${picked.size} selected, in the order tapped)", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Library.exercises.forEach { ex ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { picked = if (ex.id in picked) picked - ex.id else picked + ex.id }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(ex.id in picked, { picked = if (ex.id in picked) picked - ex.id else picked + ex.id })
                    Column(Modifier.weight(1f)) { Text(ex.name); Text("${ex.muscle} • ${ex.equip}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }
        }
        Column(Modifier.padding(16.dp).navigationBarsPadding()) {
            GradBtn("Save workout", {
                val items = picked.mapNotNull { id -> Library.ex(id)?.let { PlanEx(id, it.sets, it.amt) } }
                vm.saveCustomPlan(Plan("new", name.trim(), "Strength", "Custom", items))
                vm.pop()
            }, enabled = name.isNotBlank() && picked.isNotEmpty())
        }
    }
}

@Composable
fun ActiveScreen(vm: AppVM) {
    val w = vm.workout
    val ctx = LocalContext.current
    if (w == null) { LaunchedEffect(Unit) { vm.pop() }; return }
    var exit by remember { mutableStateOf(false) }
    var tickNow by remember { mutableLongStateOf(0L) }
    val view = LocalView.current
    DisposableEffect(Unit) { view.keepScreenOn = vm.data.settings.keepScreenOn; onDispose { view.keepScreenOn = false } }
    LaunchedEffect(w) { while (true) { w.tick(); tickNow++; delay(200) } }
    LaunchedEffect(w.setsDone, w.idx) {
        if (vm.data.settings.vibrate && (w.setsDone > 0 || w.idx > 0)) {
            try { (ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).vibrate(VibrationEffect.createOneShot(120, VibrationEffect.DEFAULT_AMPLITUDE)) } catch (_: Exception) {}
        }
    }
    BackHandler { exit = true }
    if (tickNow < 0) return
    val total = w.plan.items.size

    Column(Modifier.fillMaxSize()) {
        Header(w.plan.name, onBack = { exit = true }, actions = { Text(if (w.finished) "Done" else "${w.idx + 1}/$total", fontWeight = FontWeight.Medium, modifier = Modifier.padding(end = 8.dp)) })
        LinearProgressIndicator(progress = { w.completed.size / total.toFloat() }, Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(6.dp).clip(RoundedCornerShape(3.dp)), color = Brand.Purple)
        if (w.finished) {
            Column(Modifier.weight(1f).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                IconBox(Icons.Default.EmojiEvents, Color.White, Brand.Green, 88)
                Spacer(Modifier.height(16.dp)); Text("Workout complete!", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                Text("${fmtTime(w.totalMs / 1000)} • ${w.completed.size}/$total exercises done", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            val ex = w.ex; val it = w.item
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                IconBox(muscleIcon(ex.muscle), Color.White, Brand.Purple, 96)
                Text(ex.name, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                Text(ex.desc, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                val big: String; val sub: String; val prog: Float
                if (w.resting) { val left = ((REST_MS - w.phaseMs) / 1000f).coerceAtLeast(0f); big = "${kotlin.math.ceil(left).toInt()}s"; sub = "REST"; prog = 1f - w.phaseMs / REST_MS.toFloat() }
                else if (ex.timed) { val left = (it.amt * 1000L - w.phaseMs) / 1000f; big = fmtTime(kotlin.math.ceil(left.coerceAtLeast(0f)).toLong()); sub = "Hold / work"; prog = 1f - w.phaseMs / (it.amt * 1000f) }
                else { big = "${it.amt}"; sub = "reps"; prog = w.setsDone / it.sets.toFloat() }
                Ring(prog, 190, 14, if (w.resting) Brand.Blue else Brand.Purple) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(big, fontSize = 44.sp, fontWeight = FontWeight.ExtraBold); Text(sub, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
                Text("Set ${minOf(w.setsDone + 1, it.sets)} of ${it.sets} • Workout time ${fmtTime(w.totalMs / 1000)}", fontWeight = FontWeight.Medium)
                if (!w.running) Text("Paused", color = Brand.Orange, fontWeight = FontWeight.Bold)
                if (w.resting) OutBtn("Skip rest", { w.skipRest() })
                else if (!ex.timed) GradBtn("Complete set", { w.setDone() }, enabled = w.running, icon = Icons.Default.Check)
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            if (!w.finished) {
                FilledTonalIconButton(onClick = { w.prev() }, enabled = w.idx > 0, modifier = Modifier.size(52.dp)) { Icon(Icons.Default.SkipPrevious, "Previous exercise") }
                Box(Modifier.weight(1f)) { GradBtn(if (w.running) "Pause" else "Resume", { if (w.running) w.pause() else w.resume() }, icon = if (w.running) Icons.Default.Pause else Icons.Default.PlayArrow) }
                FilledTonalIconButton(onClick = { w.next() }, modifier = Modifier.size(52.dp)) { Icon(Icons.Default.SkipNext, "Skip to next exercise") }
            }
        }
        Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 12.dp).navigationBarsPadding()) {
            OutBtn("Finish Workout", { if (w.running) w.pause(); exit = true })
        }
    }
    if (exit) AlertDialog(
        onDismissRequest = { exit = false }, title = { Text("Finish workout?") },
        text = { Text("${w.completed.size} of $total exercises completed in ${fmtTime(w.totalMs / 1000)}. Save it to your history?") },
        confirmButton = { TextButton(onClick = { vm.saveWorkout(w); exit = false; vm.pop() }) { Text("Save", color = Brand.Purple) } },
        dismissButton = {
            Row { TextButton(onClick = { exit = false }) { Text("Keep going") }
                TextButton(onClick = { vm.discardWorkout(); exit = false; vm.pop() }) { Text("Discard", color = Brand.Red) } }
        }
    )
}
