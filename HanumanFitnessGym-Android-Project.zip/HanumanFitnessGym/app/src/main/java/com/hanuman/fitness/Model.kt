package com.hanuman.fitness

import kotlinx.serialization.Serializable
import java.time.LocalDate

@Serializable
data class UserProfile(
    val name: String = "", val age: Int = 0, val gender: String = "",
    val weightKg: Double = 0.0, val heightCm: Double = 0.0,
    val goal: String = "", val level: String = "",
    val equipment: List<String> = emptyList(), val diet: String = "Anything",
    val allergies: String = "", val activityPref: String = "",
    val photoPath: String = "", val stepGoal: Int = 8000
)

@Serializable
data class AppSettings(
    val units: String = "metric", val theme: String = "system",
    val reminderOn: Boolean = false, val reminderHour: Int = 18,
    val keepScreenOn: Boolean = true, val vibrate: Boolean = true,
    val strideCm: Int = 0, val aiUrl: String = "", val calorieTarget: Int = 0
)

@Serializable data class PlanEx(val exId: String, val sets: Int, val amt: Int)

@Serializable
data class Plan(
    val id: String, val name: String, val category: String, val level: String,
    val items: List<PlanEx>, val blurb: String = "", val generated: Boolean = false
) {
    fun estMinutes(): Int {
        var sec = 0
        for (i in items) {
            val ex = Library.ex(i.exId) ?: continue
            sec += if (ex.timed) i.sets * (i.amt + 25) else i.sets * (i.amt * 3 + 40)
        }
        return maxOf(5, (sec + 30) / 60)
    }
}

@Serializable data class WorkoutLog(val id: String, val name: String, val startedAt: Long, val durationSec: Int, val done: Int, val total: Int)
@Serializable data class RunLog(val id: String, val type: String, val startedAt: Long, val durationSec: Int, val distanceM: Double, val gps: Boolean)
@Serializable data class WeightEntry(val date: String, val kg: Double)
@Serializable data class Habit(val id: String, val name: String, val target: String = "")
@Serializable data class PlanMeal(val id: String, val date: String, val slot: String, val mealId: String, val servings: Double, val eaten: Boolean = false)
@Serializable data class StepState(val lastCounter: Long = -1, val lastDate: String = "")

@Serializable
data class AppData(
    val onboarded: Boolean = false,
    val profile: UserProfile = UserProfile(),
    val settings: AppSettings = AppSettings(),
    val customPlans: List<Plan> = emptyList(),
    val workoutLogs: List<WorkoutLog> = emptyList(),
    val runLogs: List<RunLog> = emptyList(),
    val weights: List<WeightEntry> = emptyList(),
    val habits: List<Habit> = emptyList(),
    val habitDone: Map<String, List<String>> = emptyMap(),
    val meals: List<PlanMeal> = emptyList(),
    val steps: Map<String, Int> = emptyMap(),
    val stepState: StepState = StepState(),
    val todayPlan: Map<String, String> = emptyMap()
)

fun today(): String = LocalDate.now().toString()
fun daysAgo(n: Int): String = LocalDate.now().minusDays(n.toLong()).toString()

// ---------- unit helpers (data is always stored metric) ----------
fun kgToLb(kg: Double) = kg * 2.20462
fun lbToKg(lb: Double) = lb / 2.20462
fun cmToIn(cm: Double) = cm / 2.54
fun inToCm(i: Double) = i * 2.54
fun fmt1(d: Double) = String.format(java.util.Locale.US, "%.1f", d)
fun fmtW(kg: Double, units: String) = if (units == "imperial") "${fmt1(kgToLb(kg))} lb" else "${fmt1(kg)} kg"
fun fmtDist(m: Double, units: String) =
    if (units == "imperial") String.format(java.util.Locale.US, "%.2f mi", m / 1609.344)
    else String.format(java.util.Locale.US, "%.2f km", m / 1000.0)
fun fmtTime(sec: Long): String {
    val h = sec / 3600; val m = (sec % 3600) / 60; val s = sec % 60
    return if (h > 0) String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, s)
    else String.format(java.util.Locale.US, "%02d:%02d", m, s)
}
fun fmtPace(distM: Double, sec: Long, units: String): String {
    if (distM < 50 || sec <= 0) return "--"
    val unitM = if (units == "imperial") 1609.344 else 1000.0
    val p = sec / (distM / unitM)
    val pm = (p / 60).toInt(); val ps = (p % 60).toInt()
    return String.format(java.util.Locale.US, "%d:%02d /%s", pm, ps, if (units == "imperial") "mi" else "km")
}
