package com.hanuman.fitness

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun CoachScreen(vm: AppVM) {
    var input by remember { mutableStateOf("") }
    val configured = vm.aiConfigured()
    val scroll = rememberScrollState()
    LaunchedEffect(vm.chat.size, vm.chatLoading) { scroll.animateScrollTo(scroll.maxValue) }
    Column(Modifier.fillMaxSize().imePadding()) {
        Header("AI Fitness Coach", onBack = { vm.pop() })
        Column(Modifier.weight(1f).verticalScroll(scroll).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (!configured) {
                HCard {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) { IconBox(Icons.Default.CloudOff, Brand.Orange, Brand.Orange.copy(alpha = 0.15f)); Column { Text("AI chat is unavailable", fontWeight = FontWeight.Bold); Text("No AI service has been configured. Chat answers only come from a real AI backend that you set up in Settings; the app never makes up replies.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
                    Spacer(Modifier.height(10.dp))
                    GradBtn("Open Settings", { vm.push(Route.Settings) })
                    Spacer(Modifier.height(8.dp))
                    OutBtn("Use the rule-based Workout Builder", { vm.push(Route.Builder) })
                }
            } else if (vm.chat.isEmpty()) Empty("Ask your coach", "Ask about workouts, form or nutrition. Replies come from your configured AI service.", Icons.Default.Chat)
            vm.chat.forEach { m ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
                    Box(Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(18.dp)).background(if (m.fromUser) Brand.Purple else MaterialTheme.colorScheme.surface).padding(12.dp)) {
                        Text(m.text, color = if (m.fromUser) Color.White else MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
            if (vm.chatLoading) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) { CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp); Text("Thinking…", fontSize = 13.sp) }
            vm.chatError?.let { err ->
                if (configured) HCard {
                    Text("Couldn't get a reply", fontWeight = FontWeight.Bold, color = Brand.Red); Text(err, fontSize = 13.sp)
                    TextButton(onClick = { vm.retryChat() }) { Text("Retry", color = Brand.Purple) }
                }
            }
        }
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), enabled = configured && !vm.chatLoading, placeholder = { Text(if (configured) "Type your message…" else "AI chat unavailable") }, shape = RoundedCornerShape(24.dp), maxLines = 3)
            IconButton(onClick = { vm.sendChat(input); input = "" }, enabled = configured && !vm.chatLoading && input.isNotBlank()) { Icon(Icons.AutoMirrored.Filled.Send, "Send", tint = Brand.Purple) }
        }
    }
}

@Composable
fun ProfileTab(vm: AppVM) {
    val p = vm.data.profile
    val u = vm.data.settings.units; val imp = u == "imperial"
    var name by remember(p) { mutableStateOf(p.name) }
    var age by remember(p, u) { mutableStateOf(if (p.age > 0) p.age.toString() else "") }
    var gender by remember(p) { mutableStateOf(p.gender) }
    var weight by remember(p, u) { mutableStateOf(if (p.weightKg > 0) fmt1(if (imp) kgToLb(p.weightKg) else p.weightKg) else "") }
    var height by remember(p, u) { mutableStateOf(if (p.heightCm > 0) fmt1(if (imp) cmToIn(p.heightCm) else p.heightCm) else "") }
    var goal by remember(p) { mutableStateOf(p.goal) }
    var level by remember(p) { mutableStateOf(p.level) }
    var equip by remember(p) { mutableStateOf(p.equipment.toSet()) }
    var diet by remember(p) { mutableStateOf(p.diet) }
    var allergies by remember(p) { mutableStateOf(p.allergies) }
    var act by remember(p) { mutableStateOf(p.activityPref) }
    var tried by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> if (uri != null) vm.setPhoto(uri) }

    val ageV = age.toIntOrNull()?.takeIf { it in 10..100 }
    val wIn = weight.toDoubleOrNull(); val hIn = height.toDoubleOrNull()
    val wKg = wIn?.let { if (imp) lbToKg(it) else it }?.takeIf { it in 30.0..320.0 }
    val hCm = hIn?.let { if (imp) inToCm(it) else it }?.takeIf { it in 100.0..250.0 }
    val valid = name.isNotBlank() && ageV != null && wKg != null && hCm != null

    Column(Modifier.fillMaxSize()) {
        Header("Profile", actions = { IconButton(onClick = { vm.push(Route.Settings) }) { Icon(Icons.Default.Settings, "Settings") } })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Avatar(p.photoPath, 96) { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
                Row { TextButton(onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text("Change photo", color = Brand.Purple) }
                    if (p.photoPath.isNotBlank()) TextButton(onClick = { vm.removePhoto() }) { Text("Use default", color = Brand.Red) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HCard(Modifier.weight(1f)) { Text("${vm.data.workoutLogs.size}", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp); Text("Workouts", fontSize = 12.sp) }
                HCard(Modifier.weight(1f)) { Text("${vm.data.runLogs.size}", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp); Text("Runs/walks", fontSize = 12.sp) }
                HCard(Modifier.weight(1f)) { Text(if (p.weightKg > 0) fmtW(p.weightKg, u) else "--", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp); Text("Weight", fontSize = 12.sp) }
            }
            Field("Name", name, { name = it }, error = if (tried && name.isBlank()) "Enter your name" else null)
            Field("Age", age, { age = it.filter(Char::isDigit).take(3) }, number = true, error = if (tried && ageV == null) "Age must be 10–100" else null)
            Text("Gender (optional)", fontWeight = FontWeight.Medium)
            ChipRow(listOf("Male", "Female", "Other", "Prefer not to say"), gender) { gender = if (gender == it) "" else it }
            Field(if (imp) "Weight (lb)" else "Weight (kg)", weight, { weight = it.filter { c -> c.isDigit() || c == '.' }.take(6) }, decimal = true, error = if (tried && wKg == null) "Enter a realistic weight" else null)
            Field(if (imp) "Height (inches)" else "Height (cm)", height, { height = it.filter { c -> c.isDigit() || c == '.' }.take(6) }, decimal = true, error = if (tried && hCm == null) "Enter a realistic height" else null)
            Text("Goal", fontWeight = FontWeight.Medium); ChipRow(Library.goals, goal) { goal = it }
            Text("Experience", fontWeight = FontWeight.Medium); ChipRow(Library.levels, level) { level = it }
            Text("Equipment", fontWeight = FontWeight.Medium)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Library.equipmentOptions.forEach { o -> Chip(o, o in equip) { equip = if (o in equip) equip - o else equip + o } }
            }
            Text("Dietary preference", fontWeight = FontWeight.Medium); ChipRow(Library.diets, diet) { diet = it }
            Field("Allergies (comma separated)", allergies, { allergies = it })
            Text("Activity preference", fontWeight = FontWeight.Medium); ChipRow(Library.activityPrefs, act) { act = it }
            Text("Units", fontWeight = FontWeight.Medium)
            ChipRow(listOf("metric", "imperial"), u) { nu -> vm.update { it.copy(settings = it.settings.copy(units = nu)) } }
            Spacer(Modifier.height(4.dp))
            GradBtn("Save changes", {
                tried = true
                if (valid) {
                    vm.update { it.copy(profile = it.profile.copy(name = name.trim(), age = ageV!!, gender = gender, weightKg = wKg!!, heightCm = hCm!!, goal = goal, level = level,
                        equipment = equip.toList().ifEmpty { listOf("Bodyweight") }, diet = diet, allergies = allergies.trim(), activityPref = act)) }
                    vm.notice = "Profile saved."
                }
            })
            OutBtn("Daily Habits", { vm.push(Route.Habits) })
            OutBtn("Activity: steps, run & walk", { vm.push(Route.Activity) })
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun SRow(title: String, sub: String? = null, onClick: (() -> Unit)? = null, trailing: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).let { if (onClick != null) it.clickable(onClick = onClick) else it }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Medium); if (sub != null) Text(sub, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        trailing()
    }
}

@Composable
fun SettingsScreen(vm: AppVM) {
    val ctx = LocalContext.current
    val s = vm.data.settings
    var dialog by remember { mutableStateOf("") }
    var clear by remember { mutableStateOf(false) }
    var ai by remember(s.aiUrl) { mutableStateOf(s.aiUrl) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok || Build.VERSION.SDK_INT < 33) { vm.update { it.copy(settings = it.settings.copy(reminderOn = true)) }; Reminders.schedule(ctx, s.reminderHour) }
        else vm.notice = "Notification permission denied, so reminders can't be shown."
    }
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) try { ctx.contentResolver.openOutputStream(uri)?.use { it.write(vm.exportJson().toByteArray()) }; vm.notice = "Data exported." } catch (e: Exception) { vm.notice = "Export failed: ${e.message}" }
    }
    fun upd(f: (AppSettings) -> AppSettings) = vm.update { it.copy(settings = f(it.settings)) }

    Column(Modifier.fillMaxSize()) {
        Header("Settings", onBack = { vm.pop() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            HCard {
                Text("Notifications", fontWeight = FontWeight.Bold)
                SRow("Daily workout reminder", "Shown at ${s.reminderHour}:00 each day", trailing = {
                    Switch(s.reminderOn, { on ->
                        if (on) { if (Build.VERSION.SDK_INT >= 33 && !hasPerm(ctx, Manifest.permission.POST_NOTIFICATIONS)) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            else { upd { it.copy(reminderOn = true) }; Reminders.schedule(ctx, s.reminderHour) } }
                        else { upd { it.copy(reminderOn = false) }; Reminders.cancel(ctx) }
                    })
                })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Reminder hour", Modifier.weight(1f))
                    FilledTonalIconButton(onClick = { val h = (s.reminderHour + 23) % 24; upd { it.copy(reminderHour = h) }; if (s.reminderOn) Reminders.schedule(ctx, h) }) { Icon(Icons.Default.Remove, "Earlier") }
                    Text("${s.reminderHour}:00", Modifier.padding(horizontal = 12.dp), fontWeight = FontWeight.Bold)
                    FilledTonalIconButton(onClick = { val h = (s.reminderHour + 1) % 24; upd { it.copy(reminderHour = h) }; if (s.reminderOn) Reminders.schedule(ctx, h) }) { Icon(Icons.Default.Add, "Later") }
                }
                Text("Reminders are rescheduled each time you open the app (e.g. after a phone restart).", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            HCard {
                Text("Workout preferences", fontWeight = FontWeight.Bold)
                SRow("Keep screen on during workouts", trailing = { Switch(s.keepScreenOn, { v -> upd { it.copy(keepScreenOn = v) } }) })
                SRow("Vibrate when a set is done", trailing = { Switch(s.vibrate, { v -> upd { it.copy(vibrate = v) } }) })
            }
            HCard {
                Text("Nutrition preferences", fontWeight = FontWeight.Bold)
                Text("Diet and allergies are set in Profile. Calorie target can be changed in the Nutrition tab.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(6.dp)); Text("Diet: ${vm.data.profile.diet}")
            }
            HCard {
                Text("Appearance & units", fontWeight = FontWeight.Bold)
                Text("Theme", fontSize = 13.sp); ChipRow(listOf("system", "light", "dark"), s.theme) { t -> upd { it.copy(theme = t) } }
                Spacer(Modifier.height(6.dp)); Text("Units", fontSize = 13.sp); ChipRow(listOf("metric", "imperial"), s.units) { t -> upd { it.copy(units = t) } }
                SRow("Language", "English (only language in this version)", onClick = { dialog = "lang" })
            }
            HCard {
                Text("AI Coach backend (optional)", fontWeight = FontWeight.Bold)
                Text("Enter the HTTPS address of your own AI service. The app sends your chat messages there and expects JSON like {\"reply\": \"...\"}. No API keys are stored in this app.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(ai, { ai = it.trim() }, Modifier.fillMaxWidth(), label = { Text("https://…") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri), shape = RoundedCornerShape(14.dp))
                Row { TextButton(onClick = { if (ai.isEmpty() || ai.startsWith("https://")) { upd { it.copy(aiUrl = ai) }; vm.notice = "Saved." } else vm.notice = "The address must start with https://" }) { Text("Save", color = Brand.Purple) } }
            }
            HCard {
                Text("Privacy & data", fontWeight = FontWeight.Bold)
                SRow("What is stored", "Everything stays on this device", onClick = { dialog = "privacy" })
                SRow("Export my data (JSON)", onClick = { export.launch("hanuman-fitness-data.json") })
                SRow("Delete all my data", "Resets the app", onClick = { clear = true })
            }
            HCard {
                SRow("Help & Support", onClick = { dialog = "help" })
                SRow("About", "Version 1.0.0", onClick = { dialog = "about" })
            }
            Spacer(Modifier.height(16.dp))
        }
    }
    when (dialog) {
        "lang" -> InfoDialog("Language", "This version is available in English only.") { dialog = "" }
        "privacy" -> InfoDialog("Privacy & data", "Your profile, photo, workouts, runs, steps, meals, habits, weights and settings are stored only on this phone. Nothing is uploaded unless you configure an AI backend, in which case only your chat messages are sent to it.\n\nPermissions are requested only when needed: Physical activity (step counter), Location (GPS run distance, optional), Notifications (reminders, optional).") { dialog = "" }
        "help" -> InfoDialog("Help & Support", "• Start from the Workout tab or the Quick Workout button.\n• Tap a habit's circle to mark it done.\n• Mark meals as eaten to build nutrition history.\n• Enable step counting from the Activity screen.\n• Use Export in Settings to back up your data.") { dialog = "" }
        "about" -> InfoDialog("Hanuman Fitness Gym", "Version 1.0.0\nLocal-first fitness companion. No account required.") { dialog = "" }
    }
    if (clear) ConfirmDialog("Delete all data?", "This permanently removes your profile, history and settings from this device. It cannot be undone.", "Delete everything", { clear = false; Reminders.cancel(ctx); vm.clearAll() }, { clear = false }, true)
}

@Composable
private fun InfoDialog(title: String, text: String, onClose: () -> Unit) {
    AlertDialog(onDismissRequest = onClose, title = { Text(title) }, text = { Text(text) }, confirmButton = { TextButton(onClick = onClose) { Text("OK") } })
}
