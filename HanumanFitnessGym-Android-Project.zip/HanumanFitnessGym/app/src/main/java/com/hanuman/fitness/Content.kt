package com.hanuman.fitness

import kotlin.random.Random

data class Exercise(
    val id: String, val name: String, val muscle: String, val equip: String,
    val sets: Int, val amt: Int, val timed: Boolean, val desc: String
)

data class Ing(val name: String, val qty: Double, val unit: String)

data class Meal(
    val id: String, val name: String, val slot: String, val kcal: Int,
    val protein: Int, val carbs: Int, val fat: Int, val diet: String,
    val allergens: List<String>, val ings: List<Ing>, val note: String
)

object Library {
    val goals = listOf("Build Muscle", "Lose Weight", "Stay Healthy", "Improve Endurance", "Flexibility & Mobility")
    val goalSub = mapOf(
        "Build Muscle" to "Gain strength & size", "Lose Weight" to "Burn fat & stay fit",
        "Stay Healthy" to "Improve overall wellness", "Improve Endurance" to "Boost stamina",
        "Flexibility & Mobility" to "Move better"
    )
    val levels = listOf("Beginner", "Intermediate", "Advanced")
    val levelSub = mapOf("Beginner" to "New to fitness", "Intermediate" to "Some experience", "Advanced" to "Regular training")
    val equipmentOptions = listOf("Bodyweight", "Dumbbells", "Barbell", "Bands", "Pull-up Bar")
    val muscles = listOf("Any", "Full Body", "Chest", "Back", "Shoulders", "Arms", "Legs", "Core", "Cardio", "Mobility")
    val categories = listOf("All", "Strength", "HIIT", "Cardio", "Yoga", "Weight Loss", "Muscle Gain", "Home Workout")
    val slots = listOf("Breakfast", "Lunch", "Snack", "Dinner")
    val diets = listOf("Anything", "Vegetarian", "Vegan")
    val activityPrefs = listOf("Gym", "Home", "Outdoor", "Mixed")

    private fun e(id: String, n: String, m: String, eq: String, s: Int, a: Int, t: Boolean, d: String) =
        Exercise(id, n, m, eq, s, a, t, d)

    val exercises: List<Exercise> = listOf(
        e("pushup", "Push-Up", "Chest", "Bodyweight", 3, 12, false, "Hands under shoulders, body in a straight line. Lower your chest to just above the floor, then press up."),
        e("incpush", "Incline Push-Up", "Chest", "Bodyweight", 3, 12, false, "Hands on a bench or sturdy surface. Lower your chest to the edge, then press away. Easier than a floor push-up."),
        e("diamond", "Diamond Push-Up", "Chest", "Bodyweight", 3, 8, false, "Hands close together forming a diamond. Keep elbows tucked as you lower and press. Targets triceps and inner chest."),
        e("dbpress", "Dumbbell Bench Press", "Chest", "Dumbbells", 3, 10, false, "Lie on a bench or the floor. Press dumbbells from chest level to full arm extension, then lower with control."),
        e("dbfly", "Dumbbell Fly", "Chest", "Dumbbells", 3, 12, false, "Arms slightly bent, open the dumbbells wide in an arc, then squeeze them back together over your chest."),
        e("bbbench", "Barbell Bench Press", "Chest", "Barbell", 4, 8, false, "Lower the bar to mid-chest, then press it back up. Use a spotter or safety rails for heavy loads."),
        e("pullup", "Pull-Up", "Back", "Pull-up Bar", 3, 6, false, "Hang with palms facing away. Pull your chin over the bar, then lower fully under control."),
        e("dbrow", "Dumbbell Row", "Back", "Dumbbells", 3, 10, false, "Hinge forward with a flat back. Pull the dumbbell to your hip, squeeze your shoulder blade, lower slowly."),
        e("bbrow", "Barbell Row", "Back", "Barbell", 4, 8, false, "Hinge at the hips, bar hanging below shoulders. Row the bar to your lower ribs and lower with control."),
        e("superman", "Superman Hold", "Back", "Bodyweight", 3, 30, true, "Lie face down. Lift arms, chest and legs off the floor and hold, breathing steadily."),
        e("bandrow", "Band Row", "Back", "Bands", 3, 15, false, "Anchor the band, pull handles toward your ribs, squeeze shoulder blades together, release slowly."),
        e("shpress", "Dumbbell Shoulder Press", "Shoulders", "Dumbbells", 3, 10, false, "Press dumbbells from shoulder height to overhead without arching your back, then lower slowly."),
        e("latraise", "Lateral Raise", "Shoulders", "Dumbbells", 3, 12, false, "With a slight elbow bend, lift dumbbells out to shoulder height, then lower slowly."),
        e("pike", "Pike Push-Up", "Shoulders", "Bodyweight", 3, 10, false, "Hips high in an inverted V. Bend your elbows to lower your head toward the floor, then press back up."),
        e("bandpull", "Band Pull-Apart", "Shoulders", "Bands", 3, 15, false, "Hold a band at chest height and pull it apart by squeezing your shoulder blades."),
        e("curl", "Biceps Curl", "Arms", "Dumbbells", 3, 12, false, "Elbows pinned to your sides. Curl the dumbbells up, squeeze, then lower slowly."),
        e("hammer", "Hammer Curl", "Arms", "Dumbbells", 3, 12, false, "Palms facing each other. Curl the dumbbells up without swinging your torso."),
        e("tridip", "Bench Triceps Dip", "Arms", "Bodyweight", 3, 12, false, "Hands on a bench behind you. Bend your elbows to lower your hips, then press back up."),
        e("triext", "Overhead Triceps Extension", "Arms", "Dumbbells", 3, 12, false, "Hold one dumbbell overhead with both hands. Bend elbows to lower behind your head, then extend."),
        e("squat", "Bodyweight Squat", "Legs", "Bodyweight", 3, 15, false, "Feet shoulder-width apart. Sit your hips back and down, keep your chest up, then stand."),
        e("lunge", "Alternating Lunge", "Legs", "Bodyweight", 3, 12, false, "Step forward and lower until both knees reach about 90 degrees. Push back and switch legs."),
        e("goblet", "Goblet Squat", "Legs", "Dumbbells", 3, 12, false, "Hold a dumbbell at your chest. Squat down with an upright torso, then drive up through your heels."),
        e("deadlift", "Barbell Deadlift", "Legs", "Barbell", 4, 6, false, "Hinge at the hips with a flat back and lift the bar by standing tall. Lower with control."),
        e("bbsquat", "Barbell Back Squat", "Legs", "Barbell", 4, 8, false, "Bar across upper back. Squat to at least parallel and stand. Use safety rails for heavy loads."),
        e("bridge", "Glute Bridge", "Legs", "Bodyweight", 3, 15, false, "Lie on your back, knees bent. Drive through your heels to lift your hips and squeeze your glutes."),
        e("wallsit", "Wall Sit", "Legs", "Bodyweight", 3, 40, true, "Back against a wall, thighs parallel to the floor. Hold the position."),
        e("calf", "Calf Raise", "Legs", "Bodyweight", 3, 20, false, "Rise onto your toes, pause at the top, then lower slowly."),
        e("plank", "Plank", "Core", "Bodyweight", 3, 40, true, "Forearms on the floor, body in a straight line from head to heels. Brace your core and hold."),
        e("crunch", "Crunch", "Core", "Bodyweight", 3, 20, false, "Lie on your back, knees bent. Curl your shoulders off the floor using your abs, then lower."),
        e("bicycle", "Bicycle Crunch", "Core", "Bodyweight", 3, 20, false, "Alternate bringing opposite elbow and knee together while the other leg extends."),
        e("legraise", "Lying Leg Raise", "Core", "Bodyweight", 3, 12, false, "Lie flat, lift straight legs to vertical, then lower slowly without arching your back."),
        e("climber", "Mountain Climber", "Core", "Bodyweight", 3, 30, true, "From a high plank, drive your knees alternately toward your chest at a steady pace."),
        e("twist", "Russian Twist", "Core", "Bodyweight", 3, 20, false, "Seated and leaning back slightly, rotate your torso side to side."),
        e("deadbug", "Dead Bug", "Core", "Bodyweight", 3, 12, false, "On your back, arms up, knees at 90 degrees. Lower opposite arm and leg while keeping your back flat."),
        e("jacks", "Jumping Jacks", "Cardio", "Bodyweight", 3, 40, true, "Jump your feet out while raising your arms overhead, then return. Keep a steady rhythm."),
        e("highknee", "High Knees", "Cardio", "Bodyweight", 3, 30, true, "Run in place, driving your knees to hip height."),
        e("burpee", "Burpee", "Cardio", "Bodyweight", 3, 10, false, "Squat, kick back to a plank, jump forward, then jump up with arms overhead."),
        e("jumpsquat", "Jump Squat", "Cardio", "Bodyweight", 3, 12, false, "Squat down, then explode upward. Land softly and go straight into the next rep."),
        e("skater", "Skater Hops", "Cardio", "Bodyweight", 3, 30, true, "Leap side to side, landing on one leg and swinging your arms for balance."),
        e("shadow", "Shadow Boxing", "Cardio", "Bodyweight", 3, 45, true, "Light on your feet, throw jabs, crosses and hooks at a steady pace."),
        e("buttkick", "Butt Kicks", "Cardio", "Bodyweight", 3, 30, true, "Jog in place, kicking your heels up toward your glutes."),
        e("dog", "Downward Dog", "Mobility", "Bodyweight", 2, 30, true, "Hips high, heels reaching toward the floor, arms and spine long. Breathe slowly."),
        e("child", "Child's Pose", "Mobility", "Bodyweight", 2, 40, true, "Kneel, sit back on your heels and reach your arms forward. Relax your forehead down."),
        e("catcow", "Cat-Cow", "Mobility", "Bodyweight", 2, 30, true, "On hands and knees, alternate arching and rounding your spine with your breath."),
        e("cobra", "Cobra Pose", "Mobility", "Bodyweight", 2, 30, true, "Lie face down, press your chest up with elbows slightly bent. Keep your shoulders relaxed."),
        e("warrior", "Warrior II", "Mobility", "Bodyweight", 2, 30, true, "Wide stance, front knee bent over the ankle, arms extended. Hold, then switch sides."),
        e("hamstring", "Hamstring Stretch", "Mobility", "Bodyweight", 2, 30, true, "Extend one leg and hinge forward from the hips until you feel a gentle stretch."),
        e("pigeon", "Pigeon Pose", "Mobility", "Bodyweight", 2, 40, true, "From all fours, bring one shin forward and extend the other leg back. Fold forward gently."),
        e("fold", "Seated Forward Fold", "Mobility", "Bodyweight", 2, 40, true, "Sit with legs extended and reach toward your feet with a long spine. Stop at a comfortable stretch."),
        e("shroll", "Shoulder & Neck Rolls", "Mobility", "Bodyweight", 2, 30, true, "Slowly roll your shoulders back, then gently roll your neck side to side.")
    )

    private val exMap = exercises.associateBy { it.id }
    fun ex(id: String): Exercise? = exMap[id]

    private fun p(id: String, name: String, cat: String, lvl: String, blurb: String, vararg ids: String) =
        Plan(id, name, cat, lvl, ids.map { i -> val x = exMap.getValue(i); PlanEx(i, x.sets, x.amt) }, blurb)

    val plans: List<Plan> = listOf(
        p("fullbody", "Full Body Strength", "Strength,Muscle Gain", "Intermediate", "Balanced strength session using dumbbells.", "goblet", "dbpress", "dbrow", "shpress", "lunge", "plank", "curl", "triext"),
        p("upper", "Upper Body Strength", "Strength,Muscle Gain", "Intermediate", "Chest, back, shoulders and arms.", "dbpress", "dbrow", "shpress", "latraise", "curl", "triext", "pushup", "plank"),
        p("lower", "Lower Body Strength", "Strength,Muscle Gain", "Intermediate", "Legs and glutes.", "goblet", "lunge", "bridge", "calf", "wallsit", "squat"),
        p("home", "Home Workout Basics", "Home Workout,Weight Loss", "Beginner", "No equipment needed.", "squat", "pushup", "lunge", "bridge", "plank", "crunch"),
        p("hiit", "HIIT Fat Burn", "HIIT,Weight Loss,Cardio", "Intermediate", "High intensity intervals.", "jacks", "burpee", "highknee", "jumpsquat", "climber", "skater", "buttkick"),
        p("hiitbeg", "Beginner HIIT", "HIIT,Home Workout", "Beginner", "Short intervals with gentle intensity.", "jacks", "squat", "highknee", "climber", "buttkick"),
        p("cardio", "Cardio Blast", "Cardio,Weight Loss,Home Workout", "Beginner", "Keep your heart rate up.", "jacks", "highknee", "shadow", "buttkick", "skater"),
        p("yoga", "Morning Yoga Flow", "Yoga", "Beginner", "Gentle wake-up flow.", "catcow", "dog", "cobra", "warrior", "child", "fold"),
        p("mobility", "Flexibility & Mobility", "Yoga,Home Workout", "Beginner", "Stretches for tight hips and shoulders.", "shroll", "catcow", "hamstring", "pigeon", "fold", "child"),
        p("core", "Core Crusher", "Strength,Home Workout", "Intermediate", "Abs and stabilizers.", "plank", "bicycle", "legraise", "climber", "twist", "deadbug"),
        p("dumbbell", "Dumbbell Muscle Builder", "Muscle Gain,Strength", "Intermediate", "Hypertrophy-focused dumbbell work.", "dbpress", "dbfly", "dbrow", "shpress", "latraise", "curl", "hammer", "goblet"),
        p("barbell", "Barbell Power", "Strength,Muscle Gain", "Advanced", "Heavy compound lifts. Warm up first.", "bbsquat", "bbbench", "bbrow", "deadlift", "pullup", "plank"),
        p("lowimpact", "Low Impact Weight Loss", "Weight Loss,Home Workout", "Beginner", "Joint-friendly calorie burn.", "squat", "bridge", "shadow", "deadbug", "plank", "calf"),
        p("endurance", "Endurance Circuit", "Cardio,HIIT", "Advanced", "Long work intervals to build stamina.", "burpee", "highknee", "jumpsquat", "climber", "skater", "shadow", "plank", "jacks")
    )

    fun starterPlanId(goal: String, level: String): String = when (goal) {
        "Build Muscle" -> when (level) { "Advanced" -> "barbell"; "Intermediate" -> "dumbbell"; else -> "home" }
        "Lose Weight" -> if (level == "Beginner") "lowimpact" else "hiit"
        "Improve Endurance" -> if (level == "Beginner") "cardio" else "endurance"
        "Flexibility & Mobility" -> if (level == "Beginner") "mobility" else "yoga"
        else -> if (level == "Beginner") "home" else "fullbody"
    }

    /** Rule-based generator (NOT AI). */
    fun generate(goal: String, minutes: Int, level: String, muscle: String, equip: Set<String>): Plan {
        val have = equip + "Bodyweight"
        val muscleSet: Set<String> = when {
            goal == "Flexibility & Mobility" -> setOf("Mobility")
            muscle == "Any" && (goal == "Lose Weight" || goal == "Improve Endurance") -> setOf("Cardio", "Legs", "Core")
            muscle == "Any" || muscle == "Full Body" -> setOf("Chest", "Back", "Shoulders", "Legs", "Core", "Arms")
            else -> setOf(muscle)
        }
        val pool = exercises.filter { it.muscle in muscleSet && it.equip in have }
        val rnd = Random(System.currentTimeMillis())
        val count = (minutes / 5).coerceIn(3, 12)
        val groups = pool.groupBy { it.muscle }.mapValues { it.value.shuffled(rnd).toMutableList() }
        val chosen = mutableListOf<Exercise>()
        var guard = 0
        while (chosen.size < count && guard < 200) {
            guard++
            var added = false
            for (g in groups.values) {
                if (chosen.size >= count) break
                if (g.isNotEmpty()) { chosen.add(g.removeAt(0)); added = true }
            }
            if (!added) break
        }
        val sets = when (level) { "Beginner" -> 2; "Advanced" -> 4; else -> 3 }
        val items = chosen.map { PlanEx(it.id, if (goal == "Flexibility & Mobility") it.sets else sets, it.amt) }
        val cat = when (goal) {
            "Build Muscle" -> "Muscle Gain,Strength"; "Lose Weight" -> "Weight Loss"; "Improve Endurance" -> "Cardio"
            "Flexibility & Mobility" -> "Yoga"; else -> "Strength"
        }
        return Plan("gen-" + System.currentTimeMillis(), "Generated: ${if (muscle == "Any") goal else muscle} (${minutes} min)", cat, level, items,
            "Rule-based workout built from your selections. Not AI-generated.", true)
    }

    private fun m(id: String, n: String, s: String, k: Int, p: Int, c: Int, f: Int, d: String, al: List<String>, note: String, vararg ings: Ing) =
        Meal(id, n, s, k, p, c, f, d, al, ings.toList(), note)

    val meals: List<Meal> = listOf(
        m("oats", "Banana Oats Bowl", "Breakfast", 350, 12, 62, 7, "vegan", listOf("gluten"), "Cook oats with water, top with sliced banana and seeds.", Ing("Rolled oats", 50.0, "g"), Ing("Banana", 1.0, ""), Ing("Chia seeds", 1.0, "tbsp"), Ing("Water", 200.0, "ml")),
        m("poha", "Vegetable Poha", "Breakfast", 300, 7, 52, 7, "vegan", listOf(), "Flattened rice sautéed with onion, peas and spices.", Ing("Flattened rice", 60.0, "g"), Ing("Onion", 0.5, ""), Ing("Green peas", 30.0, "g"), Ing("Oil", 1.0, "tsp"), Ing("Lemon juice", 1.0, "tsp")),
        m("eggtoast", "Egg Scramble on Toast", "Breakfast", 380, 24, 28, 18, "egg", listOf("egg", "gluten"), "Scramble eggs with spinach and serve on wholegrain toast.", Ing("Eggs", 3.0, ""), Ing("Wholegrain bread", 2.0, "slices"), Ing("Spinach", 30.0, "g"), Ing("Oil", 1.0, "tsp")),
        m("yogurt", "Greek Yogurt Berry Bowl", "Breakfast", 280, 20, 30, 8, "veg", listOf("dairy", "nuts"), "Yogurt topped with berries and a few almonds.", Ing("Greek yogurt", 200.0, "g"), Ing("Mixed berries", 80.0, "g"), Ing("Almonds", 10.0, "g")),
        m("chilla", "Moong Dal Chilla", "Breakfast", 320, 18, 42, 8, "vegan", listOf(), "Savoury lentil pancakes with mint chutney.", Ing("Moong dal (soaked)", 70.0, "g"), Ing("Onion", 0.5, ""), Ing("Green chilli", 1.0, ""), Ing("Oil", 1.0, "tsp")),
        m("chickenbowl", "Grilled Chicken Bowl", "Lunch", 550, 50, 48, 15, "nonveg", listOf(), "Grilled chicken breast over brown rice with steamed vegetables.", Ing("Chicken breast", 200.0, "g"), Ing("Brown rice (cooked)", 1.0, "cup"), Ing("Steamed vegetables", 150.0, "g"), Ing("Olive oil", 1.0, "tbsp"), Ing("Salt & spices", 1.0, "tsp")),
        m("dalrice", "Dal, Rice & Sabzi", "Lunch", 520, 20, 85, 10, "vegan", listOf(), "Lentil curry with rice and seasonal vegetables.", Ing("Toor dal (dry)", 50.0, "g"), Ing("Rice (cooked)", 1.0, "cup"), Ing("Mixed vegetables", 150.0, "g"), Ing("Oil", 2.0, "tsp")),
        m("paneerwrap", "Paneer Wrap", "Lunch", 480, 24, 45, 22, "veg", listOf("dairy", "gluten"), "Spiced paneer and veggies in a wholewheat wrap.", Ing("Paneer", 100.0, "g"), Ing("Wholewheat wrap", 1.0, ""), Ing("Capsicum & onion", 80.0, "g"), Ing("Yogurt sauce", 2.0, "tbsp")),
        m("chickpea", "Chickpea Salad Bowl", "Lunch", 430, 18, 58, 14, "vegan", listOf(), "Chickpeas, cucumber, tomato, quinoa and lemon dressing.", Ing("Cooked chickpeas", 150.0, "g"), Ing("Quinoa (cooked)", 0.5, "cup"), Ing("Cucumber & tomato", 120.0, "g"), Ing("Olive oil", 1.0, "tbsp")),
        m("fishquinoa", "Baked Fish & Quinoa", "Lunch", 500, 42, 38, 18, "nonveg", listOf("fish"), "Baked fish fillet with quinoa and greens.", Ing("White fish fillet", 180.0, "g"), Ing("Quinoa (cooked)", 1.0, "cup"), Ing("Green beans", 100.0, "g"), Ing("Olive oil", 1.0, "tsp")),
        m("chana", "Roasted Chana", "Snack", 180, 10, 28, 3, "vegan", listOf(), "Crunchy roasted chickpeas.", Ing("Roasted chana", 50.0, "g")),
        m("shake", "Whey Protein Shake", "Snack", 200, 28, 10, 4, "veg", listOf("dairy"), "One scoop whey blended with water or milk.", Ing("Whey protein", 1.0, "scoop"), Ing("Water", 300.0, "ml")),
        m("fruitnuts", "Fruit & Nut Mix", "Snack", 220, 6, 26, 11, "vegan", listOf("nuts"), "Apple with a handful of mixed nuts.", Ing("Apple", 1.0, ""), Ing("Mixed nuts", 25.0, "g")),
        m("pbtoast", "Peanut Butter Toast", "Snack", 260, 10, 28, 12, "vegan", listOf("nuts", "gluten"), "Wholegrain toast with peanut butter.", Ing("Wholegrain bread", 1.5, "slices"), Ing("Peanut butter", 1.0, "tbsp")),
        m("khichdi", "Vegetable Khichdi", "Dinner", 400, 15, 68, 7, "vegan", listOf(), "Rice and lentils cooked with vegetables.", Ing("Rice", 40.0, "g"), Ing("Moong dal", 40.0, "g"), Ing("Mixed vegetables", 100.0, "g"), Ing("Oil", 1.0, "tsp")),
        m("tofu", "Tofu Vegetable Stir-Fry", "Dinner", 380, 24, 28, 18, "vegan", listOf("soy"), "Pan-seared tofu with colourful vegetables.", Ing("Firm tofu", 150.0, "g"), Ing("Mixed vegetables", 200.0, "g"), Ing("Soy sauce", 1.0, "tbsp"), Ing("Oil", 1.0, "tsp")),
        m("chickencurry", "Chicken Curry & Roti", "Dinner", 560, 42, 50, 20, "nonveg", listOf("gluten"), "Home-style chicken curry with two rotis.", Ing("Chicken (boneless)", 150.0, "g"), Ing("Roti", 2.0, ""), Ing("Onion-tomato gravy", 150.0, "g"), Ing("Oil", 2.0, "tsp")),
        m("palak", "Palak Paneer & Roti", "Dinner", 520, 26, 44, 26, "veg", listOf("dairy", "gluten"), "Spinach and paneer curry with two rotis.", Ing("Paneer", 100.0, "g"), Ing("Spinach", 200.0, "g"), Ing("Roti", 2.0, ""), Ing("Oil", 2.0, "tsp"))
    )
    private val mealMap = meals.associateBy { it.id }
    fun meal(id: String): Meal? = mealMap[id]

    fun mealAllowed(m: Meal, diet: String, allergies: String): Boolean {
        val okDiet = when (diet) {
            "Vegan" -> m.diet == "vegan"
            "Vegetarian" -> m.diet == "vegan" || m.diet == "veg"
            else -> true
        }
        if (!okDiet) return false
        val words = allergies.lowercase().split(",", ";", " ", "\n").map { it.trim() }.filter { it.length >= 3 }
        val al = m.allergens.map { it.lowercase() } + m.ings.map { it.name.lowercase() }
        return words.none { w -> al.any { a -> a.contains(w) || w.contains(a) } }
    }

    fun estimateCalories(p: UserProfile): Int? {
        if (p.weightKg <= 0 || p.heightCm <= 0 || p.age <= 0) return null
        val base = 10 * p.weightKg + 6.25 * p.heightCm - 5 * p.age + (if (p.gender == "Female") -161 else 5)
        var kcal = base * 1.4
        when (p.goal) { "Lose Weight" -> kcal -= 400; "Build Muscle" -> kcal += 250 }
        return (kcal / 10).toInt() * 10
    }
}
