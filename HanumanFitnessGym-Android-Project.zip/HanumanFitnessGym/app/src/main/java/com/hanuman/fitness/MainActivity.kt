package com.hanuman.fitness

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    private val vm: AppVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val s = vm.data.settings
            val dark = when (s.theme) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
            HTheme(dark) {
                if (!vm.data.onboarded) Onboarding(vm) else MainShell(vm)
                vm.notice?.let { n -> AlertDialog(onDismissRequest = { vm.notice = null }, text = { Text(n) }, confirmButton = { TextButton(onClick = { vm.notice = null }) { Text("OK") } }) }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (stepPermGranted(this)) vm.startSteps()
        val s = vm.data.settings
        if (s.reminderOn) Reminders.schedule(this, s.reminderHour)
    }

    override fun onStop() {
        super.onStop()
        vm.workout?.pause()   // never keep counting workout time while the app is hidden / phone locked
        vm.stopSteps()
    }
}

private data class NavTab(val route: Route, val label: String, val icon: ImageVector)

@Composable
fun MainShell(vm: AppVM) {
    val tabs = listOf(
        NavTab(Route.Home, "Home", Icons.Default.Home), NavTab(Route.Workout, "Workout", Icons.Default.FitnessCenter),
        NavTab(Route.Nutrition, "Nutrition", Icons.Default.Restaurant), NavTab(Route.Progress, "Progress", Icons.Default.Insights),
        NavTab(Route.Profile, "Profile", Icons.Default.Person)
    )
    val top = vm.stack.last()
    val isTab = vm.stack.size == 1 && tabs.any { it.route == top }
    BackHandler(enabled = vm.stack.size > 1 || top != Route.Home) { if (!vm.pop()) vm.tab(Route.Home) }
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f)) {
            when (val r = top) {
                Route.Home -> HomeScreen(vm)
                Route.Workout -> WorkoutTab(vm)
                Route.Nutrition -> NutritionTab(vm)
                Route.Progress -> ProgressTab(vm)
                Route.Profile -> ProfileTab(vm)
                is Route.PlanDetail -> PlanDetailScreen(vm, r.id)
                Route.Active -> ActiveScreen(vm)
                Route.Builder -> BuilderScreen(vm)
                Route.CreateWorkout -> CreateWorkoutScreen(vm)
                is Route.MealDetail -> MealDetailScreen(vm, r)
                Route.Habits -> HabitsScreen(vm)
                Route.Coach -> CoachScreen(vm)
                Route.Settings -> SettingsScreen(vm)
                Route.Activity -> ActivityScreen(vm)
            }
        }
        if (isTab) {
            Surface(shadowElevation = 12.dp, color = MaterialTheme.colorScheme.surface) {
                Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceAround) {
                    tabs.forEach { t ->
                        val sel = t.route == top
                        Column(Modifier.weight(1f).clickable { vm.tab(t.route) }.padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(t.icon, t.label, tint = if (sel) Brand.Purple else MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(t.label, fontSize = 11.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal, color = if (sel) Brand.Purple else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
