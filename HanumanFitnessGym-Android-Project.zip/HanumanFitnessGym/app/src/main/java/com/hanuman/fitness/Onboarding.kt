package com.hanuman.fitness

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DirectionsRun
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private fun goalIcon(g: String) = when (g) {
    "Build Muscle" -> Icons.Default.FitnessCenter; "Lose Weight" -> Icons.Default.LocalFireDepartment
    "Stay Healthy" -> Icons.Default.Favorite; "Improve Endurance" -> Icons.Default.Bolt
    else -> Icons.Default.SelfImprovement
}

@Composable
fun Onboarding(vm: AppVM) {
    var step by rememberSaveable { mutableStateOf(0) }
    var goal by rememberSaveable { mutableStateOf("") }
    var level by rememberSaveable { mutableStateOf("") }
    var name by rememberSaveable { mutableStateOf("") }
    var age by rememberSaveable { mutableStateOf("") }
    var gender by rememberSaveable { mutableStateOf("") }
    var weight by rememberSaveable { mutableStateOf("") }
    var height by rememberSaveable { mutableStateOf("") }
    var equip by rememberSaveable { mutableStateOf("Bodyweight") }
    var diet by rememberSaveable { mutableStateOf("Anything") }
    var allergies by rememberSaveable { mutableStateOf("") }
    var act by rememberSaveable { mutableStateOf("Mixed") }
    var tried by rememberSaveable { mutableStateOf(false) }
    val imperial = vm.data.settings.units == "imperial"

    fun errs(): Map<String, String> {
        val e = mutableMapOf<String, String>()
        if (name.isBlank()) e["name"] = "Enter your name"
        val a = age.toIntOrNull(); if (a == null || a !in 10..100) e["age"] = "Age must be 10–100"
        val w = weight.toDoubleOrNull(); if (w == null || w <= 0 || (if (imperial) w !in 66.0..700.0 else w !in 30.0..320.0)) e["weight"] = "Enter a realistic weight"
        val h = height.toDoubleOrNull(); if (h == null || h <= 0 || (if (imperial) h !in 40.0..95.0 else h !in 100.0..250.0)) e["height"] = "Enter a realistic height"
        return e
    }
    fun build() = UserProfile(
        name = name.trim(), age = age.toIntOrNull() ?: 0, gender = gender,
        weightKg = (weight.toDoubleOrNull() ?: 0.0).let { if (imperial) lbToKg(it) else it },
        heightCm = (height.toDoubleOrNull() ?: 0.0).let { if (imperial) inToCm(it) else it },
        goal = goal, level = level, equipment = equip.split(",").filter { it.isNotBlank() },
        diet = diet, allergies = allergies.trim(), activityPref = act
    )
    BackHandler(enabled = step > 0) { step-- }

    when (step) {
        0 -> Box(Modifier.fillMaxSize().background(Brand.GradientV).padding(24.dp).systemBarsPadding()) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(Modifier.weight(1f))
                Image(painterResource(R.drawable.logo), "Hanuman Fitness Gym logo", Modifier.size(200.dp).clip(RoundedCornerShape(40.dp)), contentScale = ContentScale.Crop)
                Spacer(Modifier.height(28.dp))
                Text("Train Smarter With AI", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(10.dp))
                Text("Personalized workouts, meal plans and habits for a healthier you.", color = Color.White.copy(alpha = 0.9f), textAlign = TextAlign.Center, fontSize = 15.sp)
                Spacer(Modifier.weight(1f))
                Button(onClick = { step = 1 }, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Brand.Purple)) { Text("Get Started", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                TextButton(onClick = { vm.finishOnboarding(UserProfile()) }) { Text("Skip for now", color = Color.White) }
            }
        }
        1 -> Column(Modifier.fillMaxSize().systemBarsPadding().padding(24.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { TextButton(onClick = { vm.finishOnboarding(UserProfile()) }) { Text("Skip") } }
            Text("Welcome!", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text("Let's build a better you.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(24.dp))
            listOf(
                Triple(Icons.Default.AutoAwesome, "Personalized Plans", "Workouts matched to your goal and level"),
                Triple(Icons.Default.FitnessCenter, "Workout Tracking", "Timer, sets and history saved on your phone"),
                Triple(Icons.Default.Restaurant, "Nutrition Guidance", "Plan meals and see estimated calories & macros")
            ).forEach { (ic, t, s) ->
                HCard(Modifier.padding(bottom = 12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        IconBox(ic, Color.White, Brand.Purple)
                        Column { Text(t, fontWeight = FontWeight.Bold); Text(s, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            GradBtn("Continue", { step = 2 })
        }
        2 -> Column(Modifier.fillMaxSize().systemBarsPadding().padding(24.dp)) {
            Text("What's your goal?", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            Text("This helps us create a personalized plan for you.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(16.dp))
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Library.goals.forEach { g -> ChoiceCard(goalIcon(g), g, Library.goalSub[g] ?: "", g == goal) { goal = g } }
            }
            Spacer(Modifier.height(12.dp)); GradBtn("Next", { step = 3 }, enabled = goal.isNotEmpty())
        }
        3 -> Column(Modifier.fillMaxSize().systemBarsPadding().padding(24.dp)) {
            Text("What's your fitness level?", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            Text("We'll adjust the plan based on your experience.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(16.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Library.levels.forEach { l ->
                    ChoiceCard(when (l) { "Beginner" -> Icons.Default.Spa; "Intermediate" -> Icons.AutoMirrored.Filled.DirectionsRun; else -> Icons.Default.EmojiEvents }, l, Library.levelSub[l] ?: "", l == level) { level = l }
                }
            }
            GradBtn("Next", { step = 4 }, enabled = level.isNotEmpty())
        }
        4 -> Column(Modifier.fillMaxSize().systemBarsPadding().imePadding().padding(horizontal = 24.dp, vertical = 16.dp)) {
            val e = if (tried) errs() else emptyMap()
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Tell us more about you", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                Text("Used only on this device to personalize your plan.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Field("Name", name, { name = it }, error = e["name"])
                Field("Age", age, { age = it.filter(Char::isDigit).take(3) }, number = true, error = e["age"])
                Text("Gender (optional)", fontWeight = FontWeight.Medium)
                ChipRow(listOf("Male", "Female", "Other", "Prefer not to say"), gender) { gender = if (gender == it) "" else it }
                Text("Units", fontWeight = FontWeight.Medium)
                ChipRow(listOf("metric", "imperial"), vm.data.settings.units) { u -> vm.update { it.copy(settings = it.settings.copy(units = u)) }; weight = ""; height = "" }
                Field(if (imperial) "Weight (lb)" else "Weight (kg)", weight, { weight = it.filter { c -> c.isDigit() || c == '.' }.take(6) }, decimal = true, error = e["weight"])
                Field(if (imperial) "Height (inches)" else "Height (cm)", height, { height = it.filter { c -> c.isDigit() || c == '.' }.take(6) }, decimal = true, error = e["height"])
                Text("Equipment available", fontWeight = FontWeight.Medium)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Library.equipmentOptions.forEach { o ->
                        val sel = o in equip.split(",")
                        Chip(o, sel) {
                            val s = equip.split(",").filter { it.isNotBlank() }.toMutableSet()
                            if (sel) s.remove(o) else s.add(o)
                            if (s.isEmpty()) s.add("Bodyweight"); equip = s.joinToString(",")
                        }
                    }
                }
                Text("Dietary preference", fontWeight = FontWeight.Medium)
                ChipRow(Library.diets, diet) { diet = it }
                Field("Allergies (optional, comma separated)", allergies, { allergies = it })
                Text("Where do you prefer to train?", fontWeight = FontWeight.Medium)
                ChipRow(Library.activityPrefs, act) { act = it }
            }
            Spacer(Modifier.height(10.dp))
            GradBtn("Next", { tried = true; if (errs().isEmpty()) step = 5 })
        }
        else -> Column(Modifier.fillMaxSize().systemBarsPadding().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.weight(1f))
            Image(painterResource(R.drawable.logo), "Hanuman Fitness Gym logo", Modifier.size(140.dp).clip(RoundedCornerShape(30.dp)), contentScale = ContentScale.Crop)
            Spacer(Modifier.height(24.dp))
            Text("You're all set!", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(8.dp))
            Text("Your personalized fitness plan is ready to go.", textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.weight(1f))
            GradBtn("Go to Dashboard", { vm.finishOnboarding(build()) })
        }
    }
}

@Composable
private fun ChoiceCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(if (selected) Brand.Purple.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface)
            .border(if (selected) 2.dp else 1.dp, if (selected) Brand.Purple else MaterialTheme.colorScheme.outline, shape)
            .clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        IconBox(icon, if (selected) Color.White else Brand.Purple, if (selected) Brand.Purple else Brand.Purple.copy(alpha = 0.12f))
        Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold); Text(sub, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        if (selected) Icon(Icons.Default.CheckCircle, null, tint = Brand.Purple)
    }
}
