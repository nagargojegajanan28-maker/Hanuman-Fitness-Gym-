package com.hanuman.fitness

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object Brand {
    val Purple = Color(0xFF9747FF)
    val Blue = Color(0xFF2865FF)
    val Navy = Color(0xFF10172F)
    val Bg = Color(0xFFF7F8FC)
    val Green = Color(0xFF20C997)
    val Red = Color(0xFFE5484D)
    val Orange = Color(0xFFFF9F43)
    val Gradient = Brush.linearGradient(listOf(Purple, Blue))
    val GradientV = Brush.verticalGradient(listOf(Purple, Blue))
}

private val LightColors = lightColorScheme(
    primary = Brand.Purple, onPrimary = Color.White, secondary = Brand.Blue,
    background = Brand.Bg, onBackground = Brand.Navy, surface = Color.White, onSurface = Brand.Navy,
    surfaceVariant = Color(0xFFEDEFF7), onSurfaceVariant = Color(0xFF5B6280), outline = Color(0xFFD8DBEA), error = Brand.Red
)
private val DarkColors = darkColorScheme(
    primary = Brand.Purple, onPrimary = Color.White, secondary = Brand.Blue,
    background = Color(0xFF0B1020), onBackground = Color(0xFFF2F4FF), surface = Color(0xFF161D38), onSurface = Color(0xFFF2F4FF),
    surfaceVariant = Color(0xFF232B4D), onSurfaceVariant = Color(0xFFA9B0D0), outline = Color(0xFF3A4370), error = Brand.Red
)

@Composable
fun HTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors) {
        Surface(color = MaterialTheme.colorScheme.background, contentColor = MaterialTheme.colorScheme.onBackground, modifier = Modifier.fillMaxSize()) {
            content()
        }
    }
}

@Composable
fun GradBtn(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, icon: ImageVector? = null) {
    Box(
        modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(16.dp))
            .background(if (enabled) Brand.Gradient else Brush.linearGradient(listOf(Color(0xFFB9BCCB), Color(0xFFB9BCCB))))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (icon != null) Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp))
            Text(text, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        }
    }
}

@Composable
fun OutBtn(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, danger: Boolean = false, enabled: Boolean = true) {
    val c = if (danger) Brand.Red else Brand.Purple
    Box(
        modifier.fillMaxWidth().height(48.dp).clip(RoundedCornerShape(16.dp)).border(1.5.dp, if (enabled) c else Color(0xFFB9BCCB), RoundedCornerShape(16.dp)).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, color = c, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun HCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    val m = modifier.fillMaxWidth().shadow(3.dp, shape, ambientColor = Color(0x1A10172F), spotColor = Color(0x1A10172F)).clip(shape)
        .background(MaterialTheme.colorScheme.surface)
    Column((if (onClick != null) m.clickable(onClick = onClick) else m).padding(16.dp), content = content)
}

@Composable
fun Header(title: String, onBack: (() -> Unit)? = null, actions: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
        else Spacer(Modifier.width(8.dp))
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        actions()
    }
}

@Composable
fun IconBox(icon: ImageVector, tint: Color, bg: Color, size: Int = 48) {
    Box(Modifier.size(size.dp).clip(RoundedCornerShape(14.dp)).background(bg), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size((size * 0.5).dp))
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.clip(shape)
            .background(if (selected) Brand.Gradient else Brush.linearGradient(listOf(MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.surfaceVariant)))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)
    ) { Text(text, color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface, fontSize = 13.sp, fontWeight = FontWeight.Medium) }
}

@Composable
fun ChipRow(options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { Chip(it, it == selected) { onSelect(it) } }
    }
}

@Composable
fun SegTabs(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(4.dp)
    ) {
        options.forEachIndexed { i, t ->
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(11.dp))
                    .background(if (i == selected) Brand.Gradient else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent)))
                    .clickable { onSelect(i) }.padding(vertical = 9.dp),
                contentAlignment = Alignment.Center
            ) { Text(t, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = if (i == selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}

@Composable
fun Section(title: String, actionText: String? = null, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (actionText != null && onAction != null) TextButton(onClick = onAction) { Text(actionText, color = Brand.Purple) }
    }
}

@Composable
fun Ring(progress: Float, size: Int, stroke: Int, color: Color = Brand.Purple, content: @Composable () -> Unit) {
    val track = MaterialTheme.colorScheme.surfaceVariant
    Box(Modifier.size(size.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val s = stroke.dp.toPx()
            val d = Size(this.size.width - s, this.size.height - s)
            drawArc(track, 0f, 360f, false, Offset(s / 2, s / 2), d, style = Stroke(s, cap = StrokeCap.Round))
            drawArc(color, -90f, 360f * progress.coerceIn(0f, 1f), false, Offset(s / 2, s / 2), d, style = Stroke(s, cap = StrokeCap.Round))
        }
        content()
    }
}

@Composable
fun Empty(title: String, sub: String, icon: ImageVector = Icons.Default.Info, actionText: String? = null, onAction: (() -> Unit)? = null) {
    Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        IconBox(icon, Brand.Purple, Brand.Purple.copy(alpha = 0.12f), 56)
        Text(title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, textAlign = TextAlign.Center)
        Text(sub, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        if (actionText != null && onAction != null) { Spacer(Modifier.height(4.dp)); Box(Modifier.width(220.dp)) { GradBtn(actionText, onAction) } }
    }
}

@Composable
fun Field(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier, number: Boolean = false, decimal: Boolean = false, error: String? = null, single: Boolean = true) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = single, isError = error != null,
        supportingText = if (error != null) ({ Text(error) }) else null,
        keyboardOptions = KeyboardOptions(keyboardType = if (decimal) KeyboardType.Decimal else if (number) KeyboardType.Number else KeyboardType.Text),
        shape = RoundedCornerShape(14.dp), modifier = modifier.fillMaxWidth()
    )
}

@Composable
fun Avatar(photoPath: String, size: Int, onClick: (() -> Unit)? = null) {
    val bmp = remember(photoPath) {
        if (photoPath.isBlank()) null else try { android.graphics.BitmapFactory.decodeFile(photoPath)?.asImageBitmap() } catch (e: Exception) { null }
    }
    val m = Modifier.size(size.dp).clip(CircleShape).let { if (onClick != null) it.clickable(onClick = onClick) else it }
    if (bmp != null) Image(bmp, "Profile photo", m, contentScale = ContentScale.Crop)
    else Image(painterResource(R.drawable.logo), "Hanuman Fitness Gym", m, contentScale = ContentScale.Crop)
}

@Composable
fun Dot(color: Color) { Box(Modifier.size(8.dp).clip(CircleShape).background(color)) }

@Composable
fun LineChart(values: List<Float>, labels: List<String>, color: Color = Brand.Purple) {
    if (values.isEmpty()) return
    val grid = MaterialTheme.colorScheme.outline
    val txt = MaterialTheme.colorScheme.onSurfaceVariant
    Column {
        Canvas(Modifier.fillMaxWidth().height(140.dp)) {
            val mn = values.min(); val mx = values.max()
            val pad = if (mx - mn < 0.5f) 1f else (mx - mn) * 0.2f
            val lo = mn - pad; val hi = mx + pad
            for (i in 0..3) { val y = size.height * i / 3f; drawLine(grid, Offset(0f, y), Offset(size.width, y), 1f) }
            val pts = values.mapIndexed { i, v ->
                val x = if (values.size == 1) size.width / 2 else size.width * i / (values.size - 1)
                Offset(x, size.height - (v - lo) / (hi - lo) * size.height)
            }
            val path = Path(); pts.forEachIndexed { i, p -> if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y) }
            drawPath(path, color, style = Stroke(4.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            pts.forEach { drawCircle(color, 5.dp.toPx(), it); drawCircle(Color.White, 2.5.dp.toPx(), it) }
        }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            val show = if (labels.size <= 6) labels else listOf(labels.first(), labels[labels.size / 2], labels.last())
            show.forEach { Text(it, fontSize = 10.sp, color = txt) }
        }
    }
}

@Composable
fun BarChart(values: List<Float>, labels: List<String>, color: Color = Brand.Blue) {
    val txt = MaterialTheme.colorScheme.onSurfaceVariant
    val track = MaterialTheme.colorScheme.surfaceVariant
    Column {
        Canvas(Modifier.fillMaxWidth().height(130.dp)) {
            val mx = (values.maxOrNull() ?: 0f).coerceAtLeast(1f)
            val n = values.size.coerceAtLeast(1)
            val slot = size.width / n
            val bw = slot * 0.6f
            values.forEachIndexed { i, v ->
                val x = i * slot + (slot - bw) / 2
                drawRoundRect(track, Offset(x, 0f), Size(bw, size.height), androidx.compose.ui.geometry.CornerRadius(6.dp.toPx()))
                val h = size.height * (v / mx)
                if (h > 0f) drawRoundRect(color, Offset(x, size.height - h), Size(bw, h), androidx.compose.ui.geometry.CornerRadius(6.dp.toPx()))
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            val show = if (labels.size <= 8) labels else listOf(labels.first(), labels[labels.size / 2], labels.last())
            show.forEach { Text(it, fontSize = 10.sp, color = txt) }
        }
    }
}

@Composable
fun ConfirmDialog(title: String, text: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit, danger: Boolean = false) {
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) }, text = { Text(text) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirm, color = if (danger) Brand.Red else Brand.Purple) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
