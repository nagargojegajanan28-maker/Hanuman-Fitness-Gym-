package com.hanuman.fitness

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalTime

@Composable
fun HomeScreen(vm: AppVM) {
    val d = vm.data
    val hour = LocalTime.now().hour
    val greet = if (hour < 12) "Good morning" else if (hour < 17) "Good afternoon" else "Good evening"
    val name = d.profile.name.trim().split(" ").firstOrNull().orEmpty()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Column(Modifier.fillMaxWidth().background(Brand.Gradient, RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp)).statusBarsPadding().padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(d.profile.photoPath, 44) { vm.tab(Route.Profile) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (name.isEmpty()) "$greet!" else "$greet, $name!", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Ready to crush your goals today?", color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp)
                }
                IconButton(onClick = { vm.push(Route.Settings) }) { Icon(Icons.Default.Notifications, "Notifications and settings", tint = Color.White) }
            }
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Surface(Modifier.weight(1f).clickable { vm.push(Route.Builder) }, shape = RoundedCornerShape(16.dp), color = Color.White) {
                    Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.AutoAwesome, null, tint = Brand.Purple)
                        Text("Quick Workout", color = Brand.Navy, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    }
                }
                Surface(Modifier.weight(1f).clickable { vm.push(Route.Coach) }, shape = RoundedCornerShape(16.dp), color = Color.White.copy(alpha = 0.2f)) {
                    Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Chat, null, tint = Color.White)
                        Text("Chat with AI", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    }
                }
            }
        }
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Section("Today's Plan")
            val plannedId = d.todayPlan[today()]
            val plan = plannedId?.let { vm.findPlan(it) }
            val suggested = if (plan == null && d.profile.goal.isNotBlank() && d.profile.level.isNotBlank()) vm.findPlan(Library.starterPlanId(d.profile.goal, d.profile.level)) else null
            val shown = plan ?: suggested
            if (shown != null) {
                PlanRow(Icons.Default.FitnessCenter, shown.name, "${shown.estMinutes()} min • ${shown.items.size} exercises", if (plan != null) "Planned for today" else "Suggested for your goal", Brand.Blue) { vm.push(Route.PlanDetail(shown.id)) }
            } else HCard(onClick = { vm.tab(Route.Workout) }) {
                Text("No workout planned", fontWeight = FontWeight.Bold)
                Text("Browse workouts or build one, then set it as today's workout.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            val todays = d.meals.filter { it.date == today() }
            val kcal = todays.sumOf { (Library.meal(it.mealId)?.kcal ?: 0) * it.servings }.toInt()
            PlanRow(Icons.Default.Restaurant, "Meal Plan", if (todays.isEmpty()) "No meals planned yet" else "$kcal kcal (est.) • ${todays.size} meals planned", null, Brand.Green) { vm.tab(Route.Nutrition) }
            val done = (d.habitDone[today()] ?: emptyList()).count { id -> d.habits.any { it.id == id } }
            PlanRow(Icons.Default.Favorite, "Daily Habits", if (d.habits.isEmpty()) "No habits yet" else "$done/${d.habits.size} completed today", null, Brand.Orange) { vm.push(Route.Habits) }

            Section("Activity")
            val steps = vm.stepsToday()
            HCard(onClick = { vm.push(Route.Activity) }) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Ring(if (d.profile.stepGoal > 0) steps / d.profile.stepGoal.toFloat() else 0f, 84, 9) {
                        Text("$steps", fontWeight = FontWeight.Bold)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("Steps today", fontWeight = FontWeight.Bold)
                        Text(if (!vm.stepSupported) "Step sensor not available on this device" else "Goal: ${d.profile.stepGoal}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("Track a run or walk →", fontSize = 13.sp, color = Brand.Purple)
                    }
                }
            }
            val last = d.workoutLogs.lastOrNull()
            if (last != null) HCard {
                Text("Last workout", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(last.name, fontWeight = FontWeight.Bold)
                Text("${fmtTime(last.durationSec.toLong())} • ${last.done}/${last.total} exercises completed", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun PlanRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String, tag: String?, color: Color, onClick: () -> Unit) {
    HCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            IconBox(icon, color, color.copy(alpha = 0.15f))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(sub, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (tag != null) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) { Dot(Brand.Purple); Text(tag, fontSize = 12.sp, color = Brand.Purple) }
            }
            Icon(Icons.AutoMirrored.Filled.ArrowForward, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
