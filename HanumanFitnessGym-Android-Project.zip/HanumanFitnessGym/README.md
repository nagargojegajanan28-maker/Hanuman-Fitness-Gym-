# Hanuman Fitness Gym (Android)

Kotlin + Jetpack Compose, local-first, no account (login and registration screens intentionally omitted).
Package: `com.hanuman.fitness` · minSdk 26 · targetSdk 35.

## Build the APK (needs internet once, to download Gradle + Android SDK parts)

### Option A: Android Studio (easiest)
1. Install Android Studio (Koala or newer). Open this folder; accept SDK/Gradle sync prompts.
2. Menu: Build > Generate App Bundles or APKs > Generate APKs... pick **release**, or run in a terminal:
   `./gradlew assembleRelease` (if the wrapper is missing: `gradle wrapper --gradle-version 8.9` first).
3. Output: `app/build/outputs/apk/release/Hanuman Fitness Gym.apk`

### Option B: Command line
Requires JDK 17 and the Android SDK (platform 35, build-tools 34+/35).
```
gradle wrapper --gradle-version 8.9
./gradlew assembleRelease
```

### Option C: GitHub Actions
Push this folder to a GitHub repo. `.github/workflows/build.yml` builds the APK;
download "Hanuman-Fitness-Gym-APK" from the run's artifacts.

The release build is signed with the debug key so it installs directly (enable "install unknown apps").
For Play Store or long-term distribution, create your own keystore and replace `signingConfig` in `app/build.gradle.kts`.

## Install
`adb install "app/build/outputs/apk/release/Hanuman Fitness Gym.apk"` or copy the file to the phone and open it.

## What is implemented
Welcome > features > goal > level > profile setup (validated) > complete, with Skip. Home dashboard, Workout library
(14 plans, 50 exercises, categories, search, My Workouts, create workout), rule-based Workout Builder (labelled not-AI),
active workout player (timers, sets, rest, pause/resume, previous/next/skip, finish and save; auto-pauses when the app is
backgrounded), Nutrition (day selector, meal plan, servings, ingredients scale, eaten tracking, estimated macros),
Daily Habits (editable, per-day history, no auto-complete), Progress (overview/weight/workouts/nutrition, week/month, charts
drawn from saved data, empty states), Activity (live step counter via TYPE_STEP_COUNTER, run/walk with GPS or timer-only),
AI Coach screen (real backend only), Profile (all fields + photo picker + default branded avatar), Settings (reminders,
workout prefs, theme, units, language info, privacy, export JSON, delete all data).
Data: single JSON file in app-private storage. Logo from your PDF is used for launcher icons and branding.

## Optional / unconfigured
* **AI Coach**: disabled until you enter an HTTPS backend URL in Settings. Contract: POST JSON
  `{"messages":[{"role":"user|assistant","content":"..."}]}` -> `{"reply":"..."}`. Keep any AI API key on your server only.
* No cloud sync, analytics or push notifications are included. Reminders are local alarms only.

## Known limitations
* Step counting needs a hardware step counter. Steps taken while the app is closed are credited when the app is next opened (to the last day the app saw).
* GPS distance is tracked only while the app is open on screen (no foreground service); accuracy depends on the device/signal.
* Reminders are rescheduled when the app opens (not after reboot until then); inexact timing.
* Nutrition values are estimates. English only. Portrait phones only tested by design, not on devices.
* Exercise illustrations are icon-based (no bundled photos/videos).
* Launcher icon is the supplied square logo as-is (no adaptive-icon masking/cropping).
